import { GET_PLACE_ID } from "./actionTypes";

export const tableOrderPlaceId = (data) => {
  return {
    type: GET_PLACE_ID,
    payload: data,
  };
};
