import { GET_FLOATINGBAR_DATA_QUANTITY } from "./actionTypes";

export const floatingbardataquantity = (data) => {
  return {
    type: GET_FLOATINGBAR_DATA_QUANTITY,
    payload: data,
  };
};
