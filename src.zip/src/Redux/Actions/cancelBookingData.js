import {
  CANCEL_BOOKING_DATA,
  SET_CANCEL_BOOKING_RESTAURANT_DETAILS,
} from "./actionTypes";

export const cancelBookingData = (data) => {
  return {
    type: CANCEL_BOOKING_DATA,
    payload: data,
  };
};

export const SetCancelBookingRestauarantDetails = (data) => {
  return {
    type: SET_CANCEL_BOOKING_RESTAURANT_DETAILS,
    payload: data,
  };
};
