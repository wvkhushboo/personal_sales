import { TABLE_BOOKING, TABLE_BOOKING_RESPONSE, SHOW_QR_CODE_FOR_TABLE_BOOKING } from "./actionTypes";

export const setTableBookingValue = (data) => (dispatch) => {
  dispatch({
    type: TABLE_BOOKING,
    payload: data,
  });
};

export const setTableBookingResponse = (data) => (dispatch) => {
  dispatch({
    type: TABLE_BOOKING_RESPONSE,
    payload: data,
  });
};

export const setShowQrCodeForTableBooking = (data) => (dispatch) => {
  dispatch({
    type: SHOW_QR_CODE_FOR_TABLE_BOOKING,
    payload: data,
  });
};