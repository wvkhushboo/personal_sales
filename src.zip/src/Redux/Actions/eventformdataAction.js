import { EVENT_FORM_DATA } from "./actionTypes";

export const eventformdataaction = (data) => {
  return {
    type: EVENT_FORM_DATA,
    payload: data,
  };
};
