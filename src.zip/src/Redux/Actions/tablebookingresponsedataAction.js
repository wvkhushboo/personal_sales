import { TABLE_BOOKING_RESPONSE_DATA } from "./actionTypes";

export const tablebookingresponsedata = (data) => {
  return {
    type: TABLE_BOOKING_RESPONSE_DATA,
    payload: data,
  };
};
