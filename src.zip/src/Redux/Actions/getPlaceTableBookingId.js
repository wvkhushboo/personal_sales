import { GET_PLACE_TABLE_BOOKING_ID } from "./actionTypes";

export const getPlaceTableBookingId = (data) => (dispatch) => {
  dispatch({
    type: GET_PLACE_TABLE_BOOKING_ID,
    payload: data,
  });
};
