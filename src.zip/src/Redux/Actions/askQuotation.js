import {ASKQUOTATION_DATA} from "./actionTypes";

export const askQuotationData = (data) => (dispatch) => {
  dispatch({
    type: ASKQUOTATION_DATA,
    payload: data,
  });
};
