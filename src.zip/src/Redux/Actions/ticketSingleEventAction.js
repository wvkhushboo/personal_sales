import { TICKET_SINGLE_EVENT } from "./actionTypes";
import axios from "axios";

export const ticketSingleEventsAction = (id) => async (dispatch) => {
  const data = await axios
    .get(`${process.env.REACT_APP_API_URL}/get-event-details/${id}`)
    .then((res) => res.data);
  dispatch({
    type: TICKET_SINGLE_EVENT,
    payload: data.data.event_detatils,
  });
};
