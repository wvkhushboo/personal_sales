import { SET_LANGUAGE } from "./actionTypes";
export const setLanguage = (data) => (dispatch) => {
  dispatch({
    type: SET_LANGUAGE,
    payload: data,
  });
};
