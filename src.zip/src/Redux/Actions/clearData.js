import { CLEAR_DATA } from "./actionTypes";

export const clearData = (data) => (dispatch) => {
  dispatch({
    type: CLEAR_DATA,
    payload: data,
  });
};
