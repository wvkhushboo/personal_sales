import {
  ADD_MENU_TO_CART,
  EMPTY_MENU_CART,
  REMOVE_MENU_FROM_CART,
} from "./actionTypes";

export const addMenuToCart = (data) => (dispatch) => {
  dispatch({
    type: ADD_MENU_TO_CART,
    payload: data,
  });
};

export const removeMenuFromCart = (data) => (dispatch) => {
  dispatch({
    type: REMOVE_MENU_FROM_CART,
    payload: data,
  });
};

export const emptyMenuCart = () => (dispatch) => {
  dispatch({
    type: EMPTY_MENU_CART,
  });
};
