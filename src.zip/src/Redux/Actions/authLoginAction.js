import { AUTH_LOGIN } from "./actionTypes";

export const authLoginAction = (data) => {
    return {
        type: AUTH_LOGIN,
        payload: data,
    };
};
