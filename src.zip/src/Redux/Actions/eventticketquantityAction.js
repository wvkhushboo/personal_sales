import { GET_TICKET_QUANTITY } from "./actionTypes";

export const eventticketquantityaction = (data) => {
  return {
    type: GET_TICKET_QUANTITY,
    payload: data,
  };
};
