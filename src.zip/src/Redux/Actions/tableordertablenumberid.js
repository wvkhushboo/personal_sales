import { GET_TABLE_NUMBER_ID } from "./actionTypes";

export const tableOrderTableNumberId = (data) => {
  return {
    type: GET_TABLE_NUMBER_ID,
    payload: data,
  };
};
