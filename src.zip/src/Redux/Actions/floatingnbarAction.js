import { GET_FLOATINGBAR_DATA } from "./actionTypes";

export const floatingbardata = (data) => {
  return {
    type: GET_FLOATINGBAR_DATA,
    payload: data,
  };
};
