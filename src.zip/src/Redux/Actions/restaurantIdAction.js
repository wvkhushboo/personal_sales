import { RESTAURANT_ID } from "./actionTypes";

export const restaurantIdAction = (data) => {
  return {
    type: RESTAURANT_ID,
    payload: data,
  };
};
