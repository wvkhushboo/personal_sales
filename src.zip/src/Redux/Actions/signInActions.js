import {
  LOGOUT,
  SET_AUTH,
  SET_EMAIL,
  SET_PASSWORD,
  SET_TOKEN,
} from "./actionTypes";

export const setEmail = (data) => {
  return {
    type: SET_EMAIL,
    payload: data,
  };
};

export const setPassword = (data) => {
  return {
    type: SET_PASSWORD,
    payload: data,
  };
};

export const setAuth = (data) => {
  return {
    type: SET_AUTH,
    payload: data,
  };
};

export const setToken = (data) => {
  return {
    type: SET_TOKEN,
    payload: data,
  };
};

export const logout = () => {
  return {
    type: LOGOUT,
  };
};
