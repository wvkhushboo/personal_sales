import { SET_SELECTED_TICKET } from "./actionTypes";

export const updateSelectedTickets = (data) => {
  return {
    type: SET_SELECTED_TICKET,
    payload: data,
  };
};
