import { GET_TABLE_NUMBER_ } from "./actionTypes";

export const tableOrderTbaleNumber = (data) => {
  return {
    type: GET_TABLE_NUMBER_,
    payload: data,
  };
};
