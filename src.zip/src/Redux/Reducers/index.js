import { combineReducers } from "redux";
import signInReducers from "./signInReducers";
import getSingleEventReducer from "./getSingleEventReducer";
import floatingbarReducer from "./floatingbarReduer";
import addToCartReducer from "./addToCartReducer";
import tableBookingReducer from "./tableBookingReducer";
import floatingbarquantityreducer from "./floatingbarquantityreducer";
import eventticketquantityreducer from "./eventticketquantityreducer";
import eventformdatareducer from "./eventformdataReducer";
import tablebookingresponsedatareducer from "./tablebookingresponsedataReducer";
import setSearchReducer from "./searchReducer";
import setLanguageReducer from "./setLanguageReducer";
import restaurantIdReducer from "./restaurantIdReducer";
import askQuotation from "./askquotationReducer";
import authLoginReducer from "./authLoginReducer";
import ticketSingleEventReducer from "./ticketSingleEventReducer";
import cancelBookingDataReducer from "./cancelBookingDataReducer";
import tableOrderPlaceIdReducer from "./tableorderplacereducer";
import tableOrderTableNumberIdReducer from "./tableordertablenumberidreducer";
import tableOrderTableNumberReducer from "./tableordertablenumberreducer";
import getPlaceTableBookingIdReducer from "./getPlaceTableBookingIdReducer";
import eventticketformdatareducer from "./eventticketquantityreducer";
import menuCartReducer from "./menuCartReducer";

const rootReducer = combineReducers({
  signInReducers,
  floatingbarquantityreducer,
  getSingleEventReducer,
  floatingbarReducer,
  addToCartReducer,
  tableBookingReducer,
  menuCart: menuCartReducer,
  tableOrderPlaceIdReducer: tableOrderPlaceIdReducer,
  tableOrderTableNumberReducer: tableOrderTableNumberReducer,
  tableOrderTableNumberIdReducer: tableOrderTableNumberIdReducer,
  eventticketquantityreducer,
  eventformdatareducer,
  tablebookingresponsedatareducer,
  setSearchReducer,
  setLanguageReducer,
  restaurantIdReducer,
  askQuotation,
  authLoginReducer,
  ticketSingleEventReducer,
  cancelBookingDataReducer,
  getPlaceTableBookingIdReducer,
  eventticketformdatareducer,
});

export default rootReducer;
