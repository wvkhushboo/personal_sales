import { SET_LANGUAGE } from "../Actions/actionTypes";

const initialState = {
  defaultLanguage: "en",
};

const setLanguageReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_LANGUAGE: {
      return {
        ...state,
        defaultLanguage: action.payload,
      };
    }
    default:
      return state;
  }
};
export default setLanguageReducer;
