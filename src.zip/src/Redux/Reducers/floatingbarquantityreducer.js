import { GET_FLOATINGBAR_DATA_QUANTITY } from "../Actions/actionTypes";

const initialState = {
  floatingbardataquantity: [],
};

const floatingbarquantityreducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_FLOATINGBAR_DATA_QUANTITY:
      return { ...state, floatingbardataquantity: action.payload };

    default:
      return state;
  }
};

export default floatingbarquantityreducer;
