import {
  GET_TICKET_QUANTITY,
  SET_SELECTED_TICKET,
} from "../Actions/actionTypes";

const initialState = {
  eventticketquantity: [],
  selectedTickets: {},
};

const eventticketformdatareducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_TICKET_QUANTITY:
      return {
        ...state,
        eventticketquantity: action.payload,
      };

    case SET_SELECTED_TICKET:
      return { ...state, selectedTickets: action.payload };

    default:
      return state;
  }
};

export default eventticketformdatareducer;
