import { GET_SINGLE_EVENT } from "../Actions/actionTypes";
import { GET_SINGLE_EVENT_INC } from "../Actions/actionTypes";

const initialState = {
  data: undefined,
};

const getSingleEventReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_SINGLE_EVENT: {
      return {
        ...state,
        data: action.payload,
      };
    }
    case GET_SINGLE_EVENT_INC: {
      return {
        ...state,
        data: action.payload.data1,
      };
    }

    default:
      return state;
  }
};
export default getSingleEventReducer;
