import {
  GET_FLOATINGBAR_DATA,
} from "../Actions/actionTypes";

const initialState = {
  floatingbardata: [],
};

const floatingbarReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_FLOATINGBAR_DATA:
      return { ...state, floatingbardata: action.payload };

    default:
      return state;
  }
};

export default floatingbarReducer;
