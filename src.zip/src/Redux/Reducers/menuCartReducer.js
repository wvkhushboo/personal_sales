import {
  ADD_MENU_TO_CART,
  EMPTY_MENU_CART,
  REMOVE_MENU_FROM_CART,
} from "../Actions/actionTypes";

const initialState = {
  addedItems: [],
  total: 0,
};

const menuCartReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_MENU_TO_CART: {
      let existedItem = state.addedItems.find(
        (item) => item.id === action.payload.id
      );

      if (existedItem) {
        existedItem.quantity += 1;
        return {
          ...state,
          total: state.total + parseFloat(action.payload.discount_value),
        };
      } else {
        action.payload["quantity"] = 1;
        let newTotal = state.total + parseFloat(action.payload.discount_value);

        return {
          ...state,
          addedItems: [...state.addedItems, action.payload],
          total: newTotal,
        };
      }
    }
    case REMOVE_MENU_FROM_CART: {
      let existedItem = state.addedItems.find(
        (item) => item.id === action.payload.id
      );

      if (existedItem) {
        if (existedItem.quantity > 0) {
          if (existedItem.quantity === 1) {
            existedItem.quantity -= 1;
            return {
              ...state,
              addedItems: state.addedItems.filter(
                (item) => item.id !== existedItem.id
              ),
              total: state.total - parseFloat(action.payload.discount_value),
            };
          } else {
            existedItem.quantity -= 1;
            return {
              ...state,
              total: state.total - parseFloat(action.payload.discount_value),
            };
          }
        }
      }
      return { ...state };
    }
    case EMPTY_MENU_CART: {
      return {
        ...state,
        addedItems: [],
        total: 0,
      };
    }

    default:
      return state;
  }
};
export default menuCartReducer;
