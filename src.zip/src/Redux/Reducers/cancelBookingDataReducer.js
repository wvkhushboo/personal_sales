import {
  CANCEL_BOOKING_DATA,
  SET_CANCEL_BOOKING_RESTAURANT_DETAILS,
} from "../Actions/actionTypes";

const initialState = {
  cancelBookingData: [],
  cancelBookingRestaurantDetails: {},
};

const cancelBookingDataReducer = (state = initialState, action) => {
  switch (action.type) {
    case CANCEL_BOOKING_DATA:
      return { ...state, cancelBookingData: action.payload };

    case SET_CANCEL_BOOKING_RESTAURANT_DETAILS:
      return { ...state, cancelBookingRestaurantDetails: action.payload };

    default:
      return state;
  }
};

export default cancelBookingDataReducer;
