import { RESTAURANT_ID } from "../Actions/actionTypes";

const initialState = {
  restaurantId: null,
};

const restaurantIdReducer = (state = initialState, action) => {
  switch (action.type) {
    case RESTAURANT_ID:
      return { ...state, restaurantId: action.payload };

    default:
      return state;
  }
};

export default restaurantIdReducer;
