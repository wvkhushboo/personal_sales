import { GET_PLACE_ID } from "../Actions/actionTypes";

const initialState = {
  place_id: 0,
};

const tableOrderPlaceIdReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_PLACE_ID:
      return { ...state, place_id: action.payload };

    default:
      return state;
  }
};

export default tableOrderPlaceIdReducer;
