import { GET_TABLE_NUMBER_ID } from "../Actions/actionTypes";

const initialState = {
  table_number_id: 0,
};

const tableOrderTableNumberIdReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_TABLE_NUMBER_ID:
      return { ...state, table_number_id: action.payload };

    default:
      return state;
  }
};

export default tableOrderTableNumberIdReducer;
