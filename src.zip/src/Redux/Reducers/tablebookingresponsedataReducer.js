import {
  TABLE_BOOKING_RESPONSE,
  TABLE_BOOKING_RESPONSE_DATA,
  SHOW_QR_CODE_FOR_TABLE_BOOKING,
} from "../Actions/actionTypes";

const initialState = {
  tablebookingresponsedata: [],
  responseData: [],
  showQrCode: false,
  dummyState: "rerere",
};

const tablebookingresponsedatareducer = (state = initialState, action) => {
  switch (action.type) {
    case TABLE_BOOKING_RESPONSE_DATA:
      return { ...state, tablebookingresponsedata: action.payload };

    case TABLE_BOOKING_RESPONSE:
      return { ...state, responseData: action.payload };

    case SHOW_QR_CODE_FOR_TABLE_BOOKING:
      return { ...state, showQrCode: action.payload };

    default:
      return state;
  }
};

export default tablebookingresponsedatareducer;
