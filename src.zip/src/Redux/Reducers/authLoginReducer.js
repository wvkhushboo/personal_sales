import { AUTH_LOGIN } from "../Actions/actionTypes";

const initialState = {
    authUser: [],
};

const authLoginReducer = (state = initialState, action) => {
    switch (action.type) {
        case AUTH_LOGIN:
            return { ...state, authUser: action.payload };

        default:
            return state;
    }
};

export default authLoginReducer;
