import {ASKQUOTATION_DATA} from '../Actions/actionTypes'

const initialState = {
  askquotationData:{}
};

const askQuotation = (state = initialState, action) => {
  switch (action.type) {
    case ASKQUOTATION_DATA: {
      return {
        ...state,
        askquotationData: action.payload,
      };
    }

    default:
      return state;
  }
};
export default askQuotation;
