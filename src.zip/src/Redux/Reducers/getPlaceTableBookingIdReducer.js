import { GET_PLACE_TABLE_BOOKING_ID } from "../Actions/actionTypes";

const initialState = {
  searchQuery: [],
};

const getPlaceTableBookingIdReducer = (state = initialState, action) => {

  switch (action.type) {
    case GET_PLACE_TABLE_BOOKING_ID: {
      return {
        ...state,
        searchQuery: action.payload,
      };
    }

    default:
      return state;
  }
};
export default getPlaceTableBookingIdReducer;
