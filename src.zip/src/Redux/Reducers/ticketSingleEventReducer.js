import { TICKET_SINGLE_EVENT } from "../Actions/actionTypes";


const initialState = {
    singleTicket: {},
};

const ticketSingleEventReducer = (state = initialState, action) => {
    switch (action.type) {
        case TICKET_SINGLE_EVENT: {
            return {
                ...state,
                singleTicket: action.payload,
            };
        }


        default:
            return state;
    }
};
export default ticketSingleEventReducer;
