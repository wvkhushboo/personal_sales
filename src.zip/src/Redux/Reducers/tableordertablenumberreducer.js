import { GET_TABLE_NUMBER_ } from "../Actions/actionTypes";

const initialState = {
  table_number: 0,
};

const tableOrderTableNumberReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_TABLE_NUMBER_:
      return { ...state, table_number: action.payload };

    default:
      return state;
  }
};

export default tableOrderTableNumberReducer;
