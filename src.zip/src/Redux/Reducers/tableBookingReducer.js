import { TABLE_BOOKING } from "../Actions/actionTypes";
const initialState = {
  formValue: {
    name: "",
    emailAddress: "",
    mobileNumber: "",
    guestCount: "",
    whatsappNumber: "",
    date: "",
    time: "",
    placeAreaName: "",
    placeAreaDetails: "",
    week_day_status: [],
    timeSlotsAvailable: false,
    restaurantOpentime: "",
    restaurantClosetime: "	",
    selectedTime: "",
    booking_fee: "20",
  },
};

const tableBookingReducer = (state = initialState, action) => {
  switch (action.type) {
    case TABLE_BOOKING: {
      return {
        ...state,
        formValue: action.payload,
      };
    }

    default:
      return state;
  }
};
export default tableBookingReducer;
