import {
  LOGOUT,
  SET_AUTH,
  SET_EMAIL,
  SET_PASSWORD,
  SET_TOKEN,
} from "../Actions/actionTypes";

const initialState = {
  email: "",
  password: "",
  isAuth: false,
  token: "",
};

const signInReducers = (state = initialState, action) => {
  switch (action.type) {
    case SET_EMAIL:
      return { ...state, email: action.payload };
    case SET_PASSWORD:
      return { ...state, password: action.payload };
    case SET_AUTH:
      return { ...state, isAuth: action.payload };
    case SET_TOKEN:
      return { ...state, token: action.payload };
    case LOGOUT:
      return { ...state, email: "", password: "", isAuth: false, token: "" };
    default:
      return state;
  }
};

export default signInReducers;
