import { EVENT_FORM_DATA } from "../Actions/actionTypes";

const initialState = {
  eventticketformdata: {},
};

const eventformdatareducer = (state = initialState, action) => {
  switch (action.type) {
    case EVENT_FORM_DATA:
      return { ...state, eventticketformdata: action.payload };

    default:
      return state;
  }
};

export default eventformdatareducer;
