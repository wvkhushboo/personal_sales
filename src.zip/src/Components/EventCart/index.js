import React, { useEffect, useState } from "react";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
import "./style.scss";

import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import {
  errorNotify,
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication";
import { loadStripe } from "@stripe/stripe-js";
import { tablebookingresponsedata } from "../../Redux/Actions/tablebookingresponsedataAction";
import Header from "../../Pages/MainViews/Header/index";
import { Button } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { floatingbardataquantity } from "../../Redux/Actions/floatingbarquantity";

const EventCart = (props) => {
  const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_KEY);
  const [isDisabled, setIsDisabled] = useState(false);
  const [counter, setCounter] = useState(5);
  const [disNone, setDisNone] = useState("none");

  const dispatch = useDispatch();
  const ticketquantity = useSelector(
    (state) => state.eventticketquantityreducer.eventticketquantity
  );
  const floatingbardata = useSelector(
    (state) => state.floatingbarReducer.floatingbardata
  );
  const eventformdata = useSelector(
    (state) => state.eventformdatareducer.eventticketformdata
  );

  const ticketQuantity = useSelector(
    (state) => state.floatingbarquantityreducer.floatingbardataquantity
  );
  const eventData = useSelector(
    (state) => state.ticketSingleEventReducer.singleTicket
  );
  const sessiondata = useSelector(
    (state) => state.tablebookingresponsedatareducer.tablebookingresponsedata
  );

  useEffect(() => {
    const handleclick = () => {
      let menus_data_arr = [];
      const ticket_count = parseFloat(
        ticketQuantity.reduce((a, b) => a + b, 0)
      );
      const booking_amount = parseFloat(
        floatingbardata.reduce((a, b) => a + b, 0)
      );
      ticketquantity?.map((item) =>
        menus_data_arr.push({
          people_id: item?.person_id,
          count: item?.intital_quantity,
        })
      );

      let restaurantId = eventData.event_place[0].id;

      const formData = new FormData();
      formData.append("venue_admin_id", eventData && eventData?.user_id);
      formData.append("restaurant_id", restaurantId);
      formData.append("place_area_id", eventData.event_place[0].place_area_id);
      formData.append("customer_email", eventformdata && eventformdata?.email);
      formData.append("guest_count", ticket_count);
      formData.append("booking_amount", booking_amount);
      formData.append("event_id", eventData && eventData?.id);
      formData.append("people_price_data", JSON.stringify(menus_data_arr));
      formData.append(
        "return_url",
        `${window.location.origin}${window.location.pathname}/stripe-event`
      );

      axios
        .post(`${process.env.REACT_APP_API_URL}/event-booking`, formData)
        .then((res) => {
          if (res.data.status === "200") {
            console.log(res.data.data);
            dispatch(tablebookingresponsedata(res.data.data));
          } else if (res.data.status === "201") {
            errorNotify(res.data.message);
            document.getElementById("Error").style.cssText = `
            display:block;
            text-align:center;
            `;
            setIsDisabled(true);
          } else {
            internalErrorNotify();
          }
        })
        .catch((error) => {
          if (error.response.status === 401) {
            unauthenticatedNotify(props.history);
          } else {
            internalErrorNotify();
          }
        });
    };
    handleclick();
  }, []);

  // this code is for counter from 5 to 1 and redirecting to home page.
  if (isDisabled) {
    setTimeout(() => {
      setCounter(counter - 1);
      if (counter === 0) {
        props.history.push("/");
      }
    }, 1000);
  }

  const handleStripeRedirection = async (sessiondata) => {
    dispatch(floatingbardataquantity([]));
    const session = await sessiondata?.map(
      (i) => i?.stripe_checkout_session_id
    );
    var sessionDataId = await session?.[0];

    const stripe = await stripePromise;
    // When the customer clicks on the button, redirect them to Checkout.

    const result = await stripe.redirectToCheckout({
      sessionId: sessionDataId,
    });

    if (result.error) {
    }
  };
  const {
    formState: { errors },
  } = useForm();

  return (
    <div className="eventCartComponent">
      <div className="hide-xs">
        <Header />
      </div>
      <div className="hide-md">
        <div className="headerBlue text-center">
          <h1>Confirm & Pay</h1>
        </div>
      </div>
      <div className="container mt-5 ">
        <table className="fullWidth">
          <thead>
            <tr className="headTr">
              <th className="text-center">
                {" "}
                <b>List of Items</b>
              </th>
              <th className="text-center">
                <b>Units</b>{" "}
              </th>
              <th className="text-center">
                {" "}
                <b>Total</b>{" "}
              </th>
            </tr>
          </thead>
          <tbody>
            {ticketquantity &&
              ticketquantity?.map((ticketItem, index) => (
                <>
                  <tr className="bodyTr" key={index}>
                    <td className="text-center">
                      {" "}
                      <h3>
                        {(ticketItem?.person_type).charAt(0).toUpperCase() +
                          (ticketItem?.person_type).slice(1)}
                      </h3>
                    </td>
                    <td className="text-center">
                      <h2>{ticketItem?.intital_quantity}</h2>
                    </td>
                    <td className="text-center">
                      <h2>
                        &euro;{" "}
                        {ticketItem?.amount
                          ? ticketItem?.amount.toFixed(2)
                          : ticketItem?.sales_price.toFixed(2)}
                      </h2>
                    </td>
                  </tr>
                </>
              ))}
          </tbody>
          <tfoot>
            <tr className="borderDotter"></tr>
            <tr className="footTr borderTop_1">
              <td colSpan="3">
                <p>
                  <b>Order Total</b>
                </p>
              </td>
              <td colSpan="2" className="text-right">
                <p>
                  <strong>
                    &euro;
                    {parseFloat(
                      floatingbardata.reduce((a, b) => a + b, 0).toFixed(2)
                    )}{" "}
                  </strong>
                </p>
              </td>
            </tr>
          </tfoot>
        </table>
        <div className="addTipSection">
          <div>
            <Button
              className="btn"
              variant="primary"
              onClick={() => handleStripeRedirection(sessiondata)}
              disabled={isDisabled}
            >
              <div className="row">
                <div className="col-md-12 col-12 text-center">Pay</div>
              </div>
            </Button>{" "}
            <div className="fs-6" style={{ display: "none" }} id="Error">
              Page will automatically redirect to HomePage in{" "}
              <span style={{ color: "blue" }}>
                <b>{counter}</b>
              </span>{" "}
              seconds...
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventCart;
