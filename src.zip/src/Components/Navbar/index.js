import React from "react";

import { NavBar } from "antd-mobile";

import "./index.css";

const Navbar = ({ title, leftIcon, rightIcon }) => {
  return (
    <>
      <NavBar
        left={leftIcon}
        right={rightIcon}
        backArrow={false}
        className={"navbar"}
      >
        {title}
      </NavBar>
    </>
  );
};

export default Navbar;
