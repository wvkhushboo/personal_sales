import React, { useState } from "react";
import Navbar from "../Navbar";
import { useForm } from "react-hook-form";
import Logo from "../../Assets/Images/logo-black.png";

import "./index.css";
import { Button } from "antd-mobile";
import {
  setAuth,
  setPassword,
  setToken,
} from "../../Redux/Actions/signInActions";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import EyeVisibleIcon from "../../Assets/Icons/EyeVisibleIcon";
import EyeInvisibleIcon from "../../Assets/Icons/EyeInvisibleIcon";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import axios from "axios";
import { Alert } from "react-bootstrap";
import { useEffect } from "react";
import { errorNotify } from "../../helpers/notiication";

const Password = () => {
  const [alertMessage, setAlertMessage] = useState(false);
  const userData = useSelector((state) => state.signInReducers);

  const logData = JSON.parse(localStorage.getItem("Login"));

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
  });

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const emailData = useSelector((state) => state.signInReducers.email);

  const [passwordToggle, setPasswordToggle] = useState(false);
  const [isChecked, setIsChecked] = useState(false);

  const fetchDataforget = async () => {
    try {
      const { data: response } = await axios.post(
        `${process.env.REACT_APP_API_URL}/forgot-password`,
        {
          email: emailData,
        }
      );
      setAlertMessage(response.message);
    } catch (error) {
      console.error(error.message);
    }
  };

  const onSubmit = (data) => {
    dispatch(setPassword(data.password));

    const fetchData = async () => {
      try {
        const { data: response } = await axios({
          method: "post",
          url: `${process.env.REACT_APP_API_URL}/login`,
          data: {
            email: emailData,
            password: data.password,
            role: 3,
          },
        });

        if (response.message === "Login Successfully") {
          dispatch(setAuth(true));
          dispatch(setToken(response.data.token));
          // setItem(keyName, keyValue)
          localStorage.setItem(
            "Login",
            JSON.stringify({
              isAuth: response.data.token ? true : false,
              token: response.data.token,
            })
          );

          if (logData.isAuth) {
            navigate("/account", { replace: true });
          }

          // window.localStorage.setItem(
          //   "Login",
          //   JSON.stringify({
          //     login: response.data.token ? true : false,
          //     token: response.data.token,
          //   })
          // );
        } else {
          // setAlertMessage(response.message + "! Redirecting...");
          errorNotify(response.message + "!");
        }

        // const restaurant_name =
        //   response.data.place_data &&
        //   response.data.place_data
        //     .map((item) => item.restaurant_name)
        //     .toString();

        // const place_area_name =
        //   response.data.place_data &&
        //   response.data.place_data
        //     .map((item) => item.place_area_name)
        //     .toString();

        // response.data.place_data &&
        //   response.data &&
        //   dispatch(Restaurant_areaAction(place_area_name));
        // response.data.place_data &&
        //   response.data &&
        //   dispatch(RESTAURANT_NAME_ACTION(restaurant_name));
        // dispatch(firstNameActions(response.data.first_name));
        // dispatch(lastNameActions(response.data.last_name));

        // if (JSON.parse(localStorage.getItem("Login")).login) {
        //   navigate("/account");
        // }
      } catch (error) {
        // alert("Some thing went worng");

        console.error(error.message);
      }
    };

    fetchData();
  };

  const saveEmailPasswordInLocalStorage = () => {
    const password = document.getElementById("userPassword").value;
    if (password) {
      if (isChecked) {
        localStorage.removeItem("userData");
      } else if (!isChecked) {
        localStorage.setItem(
          "userData",
          JSON.stringify({ email: emailData, hash: window.btoa(password) })
        );
      }
    }
  };

  useEffect(() => {
    if (logData?.isAuth) {
      navigate("/account", { replace: true });
    }

    if (!userData?.email) {
      navigate("/");
    }
  }, [navigate, userData, logData]);

  return (
    <>
      <Navbar title="Sign In" leftIcon={<ArrowLeftIcon />} />

      <div className="container myPasswordContainer">
        <div className="alert-div mb-4">
          <Alert show={!!alertMessage} variant={"warning"}>
            <button onClick={() => setAlertMessage("")}>x</button>
            <span>{alertMessage}</span>
          </Alert>
        </div>

        <div className="passwordLogo text-center">
          <img src={Logo} alt="logo-black" />
        </div>

        <div className="passwordForm mt-5">
          <h6 className="font-weight-bold">Sign In for Sales Person</h6>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-4">
            <div className="form-group">
              <p className="formLabel font-weight-bold">Password</p>
              <div className="passwithicon">
                <input
                  id="userPassword"
                  className="form-control inputField"
                  type={passwordToggle ? "text" : "password"}
                  autoComplete="off"
                  {...register("password", {
                    required: "Password is required",
                    pattern: {
                      value: RegExp("(?=.*?[0-9])(?=.*?[A-Za-z]).+"),
                      message:
                        "Password should contain atleast one number and one alphabet",
                    },
                  })}
                />
                {errors.password && (
                  // <span className="input-error">{errors.email.message}</span>
                  <div className="alert alert-danger mt-3" role="alert">
                    {errors.password.message}
                  </div>
                )}
                {passwordToggle ? (
                  <EyeVisibleIcon onClick={() => setPasswordToggle(false)} />
                ) : (
                  <EyeInvisibleIcon onClick={() => setPasswordToggle(true)} />
                )}
              </div>
              <div className="alignHorizontal pb-3">
                <div className="rememberMe">
                  <span
                    onClick={() => saveEmailPasswordInLocalStorage()}
                    style={{
                      color: "#526BF3",
                      float: "left",
                    }}
                  >
                    <input
                      className="me-2"
                      type="checkbox"
                      checked={isChecked}
                      id="rememberMe"
                      onChange={() => setIsChecked(!isChecked)}
                      // onClick={() => setIsChecked(!isChecked)}
                    ></input>
                    <span className="checkmark"></span>
                    <label
                      style={{ cursor: "pointer" }}
                      // onChange={() => setIsChecked(!isChecked)}/
                      onClick={() => setIsChecked(!isChecked)}
                      htmlFor="remeberMe"
                    >
                      Remember me{" "}
                    </label>
                  </span>
                </div>
                <div className="forgotPass">
                  <p className="text-end">
                    <u>
                      <span
                        style={{
                          color: "#526BF3",
                          float: "right",
                          cursor: "pointer",
                        }}
                        onClick={() => {
                          fetchDataforget();
                        }}
                      >
                        Forgot Password?
                      </span>
                    </u>
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-3">
              <Button
                block
                shape="rounded"
                type="submit"
                style={{ backgroundColor: "#526bf3", color: "white" }}
              >
                Sign In
              </Button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Password;
