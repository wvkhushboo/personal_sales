import React, { useState } from "react";
import { Modal, Button } from "antd";
import "./failed.scss";

import { CloseCircleOutlined } from "@ant-design/icons";

import { useNavigate } from "react-router-dom";

function FailedPopUpModal({ url, message }) {
  const navigate = useNavigate();

  const [isModalVisible, setIsModalVisible] = useState(true);
  const handleOk = () => {
    setIsModalVisible(false);
    if (url) navigate(url);
    if (message)
      window.history.pushState({}, "", `${window.location.pathname}`);
    else navigate("/account");
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    if (message)
      window.history.pushState({}, "", `${window.location.pathname}`);
  };
  return (
    <div className="failedComponent">
      <Modal
        footer={[
          <Button
            className="failedBtn"
            key="submit"
            type="primary"
            onClick={handleOk}
          >
            OK
          </Button>,
        ]}
        width="300px"
        height="150px"
        style={{ textAlign: "center" }}
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        closeIcon=" "
      >
        <CloseCircleOutlined style={{ fontSize: "50px", color: "red" }} />

        <div>
          <h4 style={{ marginTop: "19px", fontWeight: "bold" }}>
            Payment Cancelled{" "}
          </h4>
          <p style={{ marginBottom: "-1em", fontWeight: "bold" }}>
            Please Try Again
          </p>
        </div>
      </Modal>
    </div>
  );
}

export default FailedPopUpModal;
