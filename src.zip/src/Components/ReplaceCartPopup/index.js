import React from "react";
import { Modal, Button } from "antd";
import "./style.scss";
import { ShoppingCartOutlined } from "@ant-design/icons";
import { useDispatch } from "react-redux";
import { updateSelectedTickets } from "../../Redux/Actions/eventTicketActions";

const ReplaceCartPopup = ({
  totalArray,
  totalQuantity,
  setReplaceCartPopup,
  eventID,
}) => {
  const dispatch = useDispatch();

  const ReplaceCart = () => {
    dispatch(
      updateSelectedTickets({
        totalArray,
        totalQuantity,
        eventID,
      })
    );
    setReplaceCartPopup(false);
  };

  return (
    <div className="replaceCartModal">
      <Modal
        footer={[
          <div className="row replaceBtns">
            <Button
              className="failedBtn col-6"
              type="primary"
              key={"1"}
              onClick={ReplaceCart}
            >
              Replace
            </Button>
            <Button
              className="failedBtn col-6"
              key="submit"
              type="primary"
              onClick={() => setReplaceCartPopup(false)}
            >
              Keep selected
            </Button>
          </div>,
        ]}
        width="400px"
        height="150px"
        style={{ textAlign: "center" }}
        open={true}
        onOk={() => setReplaceCartPopup(false)}
        closeIcon=" "
      >
        <ShoppingCartOutlined style={{ fontSize: "70px" }} />

        <div className="mt-3">
          <p style={{ marginBottom: "-1em" }} className="mt-3">
            You have already selected a ticket, please complete your current
            reservation and you can book a new ticket.
          </p>
          <p style={{ fontWeight: "bold" }} className="mt-4 mb-0">
            Do you want to replace the current reservation with a new one?
          </p>
        </div>
      </Modal>
    </div>
  );
};

export default ReplaceCartPopup;
