import React, { useState } from "react";
import { Modal, Button } from "antd";
import thankYouSmiley from "../../Assets/Images/Smiley.png";
import "./style.scss";

function SuccessPopModal(props) {
  const [isModalVisible, setIsModalVisible] = useState(true);
  const handleOk = () => setIsModalVisible(false);
  const handleCancel = () => setIsModalVisible(false);
  return (
    <div className="successPopModalComponent">
      <Modal
        className="modalBody"
        footer={[
          <Button
            style={{ width: "80%", borderRadius: "15px", marginBottom: "8px" }}
            className="successBtn"
            key="submit"
            type="primary"
            onClick={() => {
              setIsModalVisible(false);
            }}
          >
            OK
          </Button>,
        ]}
        width="300px"
        height="150px"
        style={{ textAlign: "center" }}
        open={isModalVisible}
        onOk={props.handleOkBtn ? props.handleOkBtn : handleOk}
        onCancel={handleCancel}
        closeIcon=" "
      >
        <img src={thankYouSmiley} width="80px" alt="thank you"></img>
        <h4 style={{ marginTop: "7px", fontWeight: "bold" }}>Thank You </h4>
        <p style={{ marginBottom: "-1em", fontWeight: "bold" }}>
          {props.title ? props.title : "Your table has been booked"}
        </p>
      </Modal>
    </div>
  );
}

export default SuccessPopModal;
