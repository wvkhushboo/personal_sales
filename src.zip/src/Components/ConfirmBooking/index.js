import React from "react";
import * as moment from "moment";
import "./style.scss";
import ShareIconModule from "../../Components/ShareIconModule";
import ShareIcon from "../../Assets/Icons/ShareIcon";
import { useState } from "react";
import { useEffect } from "react";
import { DownloadOutlined } from "@ant-design/icons";

export default function ConfirmBooking({
  maindata,
  restaurantName,
  bookingFees,
}) {
  const [shareShow, setShareShow] = useState(false);
  const [resTicketDetail, setResTicketDetail] = useState({
    number_id: "",
    booking_date: "",
    qrImage: "",
    customer_email: "",
    time: "",
    total_people: "",
  });

  useEffect(() => {
    const handleClickDetail = () => {
      setResTicketDetail({
        number_id: maindata[0].number_id,
        booking_date: moment(maindata[0]?.date * 1000).format("DD MMM"),
        qrImage: maindata[0]?.booking_qr_code,
        customer_email: maindata[0]?.customer_email,
        time: maindata[0]?.time,
        total_people: maindata[0]?.total_people,
      });
    };
    handleClickDetail();
    //eslint-disable-next-line
  }, []);

  function printDivContent() {
    window.print();
  }

  return (
    <div className="confirmBookingComponent" id="printableArea">
      <div id="mydiv">
        <h3 className="heading_3 text-center">Booking Confirmed</h3>

        <div className="checkoutBookingConfirmation mb-30">
          <div className="cbc_check">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20.23"
              height="18.49"
              viewBox="0 0 13.23 9.49"
            >
              <path
                id="Path_17"
                data-name="Path 17"
                d="M8163.657,4052.471l3.328,3.328,7.074-7.075"
                transform="translate(-8162.243 -4047.31)"
                fill="none"
                stroke="#fff"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
            </svg>
          </div>
          <div className="d-flex justify-content-end ">
            <DownloadOutlined
              className="downloadBtn "
              onClick={() => printDivContent()}
            />{" "}
            <div className="noprint">
              <ShareIcon
                style={{
                  cursor: "pointer",
                  marginLeft: "10px",
                  color: "#536BF3",
                  marginTop: "1px",
                }}
                onClick={() => setShareShow(true)}
              ></ShareIcon>
            </div>
            <ShareIconModule
              resTicketDetail={resTicketDetail}
              shareShow={shareShow}
              setShareShow={setShareShow}
            />
          </div>
          <div className="text-center">
            <img
              src={`${process.env.REACT_APP_API_URL.slice(0, -3)}${
                maindata[0]?.booking_qr_code
              }`}
              alt="qr-code"
              className="mb-15 qrCodeImg "
              style={{ width: "40%" }}
            />

            <h4 className="heading_5">Booking ID {maindata[0].number_id}</h4>
            <h6 className="mb-10 mt-3" style={{ fontWeight: 600 }}>
              Booking Confirmed For {maindata[0]?.total_people}{" "}
              {parseInt(maindata[0]?.total_people) === 1 ? "Guest" : "Guests"}
            </h6>
            <p className="mb-1">
              <b>Booking Slot - </b>
              {moment(maindata[0]?.date * 1000).format("DD MMM")} at{" "}
              {maindata[0]?.time}
            </p>
            <p>
              Hey, We have sent the tickets to {maindata[0]?.customer_email}
            </p>
          </div>

          <div className="col-12 mt-5">
            <div className="booking__confirm__seller d-flex">
              <div className="col-8 ">
                <h5 className="fw-bold">SELLER</h5>
                <p className="date" style={{ marginTop: "-10px" }}>
                  {restaurantName}
                </p>
              </div>
              <div
                className="col-4 "
                style={{ display: "grid", placeItems: "end" }}
              >
                <h5 className="fw-bold">PRICE</h5>
                <p className="date" style={{ marginTop: "-10px" }}>
                  {bookingFees}
                </p>
              </div>
            </div>
          </div>
          <div className="m-3">
            <h5 className="fw-bold">BOOKING DATE</h5>
            <p className="date" style={{ marginTop: "-10px" }}>
              {moment().format("DD MMM YYYY, HH:mm")}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
