import React from "react";
import "./style.scss";
import { notification } from "antd";
import Emailshare from "../../Assets/Images/email.jpg";

import { FacebookShareButton, WhatsappShareButton } from "react-share";

import { FacebookIcon, WhatsappIcon } from "react-share";

//  copy input text
const copyText = () => {
  let inputText = document.getElementById("copyText");
  inputText.select();
  navigator.clipboard.writeText(inputText.value);

  notification.info({
    message: "Link Copied",
  });
};
const ShareIconModule = ({
  shareShow,
  setShareShow,
  ticketDetail,
  resTicketDetail,
}) => {
  return (
    <div className="shareIconModuleComponent">
      <div className="main">
        <div
          style={{ display: shareShow && "block" }}
          className={`modal fade share_icon_modal ${shareShow && "show in"}`}
          id="exampleModal"
          tabIndex={-1}
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog modal__dialog">
            <div className="modal-content modal__content">
              <div className="modal-header modal__header">
                <h5 className="modal-title modal__title" id="exampleModalLabel">
                  Share
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={() => setShareShow(false)}
                />
              </div>
              <div className="modal-body modal__body">
                <div className="icon-container d-flex justify-content-center ">
                  <FacebookShareButton
                    url={window.location.href}
                    style={{ marginRight: "10px" }}
                  >
                    <FacebookIcon
                      className="icon"
                      logofillcolor="white"
                      round={true}
                      width="45px"
                    ></FacebookIcon>
                    <p className="icon-title">Facebook </p>
                  </FacebookShareButton>

                  <div
                    style={{
                      alignItems: "center",
                      marginRight: "10px",
                      marginLeft: "5px",
                      marginTop: "15px",
                      alignSelf: "center",
                    }}
                  >
                    <a
                      href={`https://mail.google.com/mail/?view=cm&fs=1&su=Restaurant &body=click the link below ${window.location.origin}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <img
                        src={Emailshare}
                        alt=""
                        style={{
                          borderRadius: "50px",
                          width: "45px",
                          marginBottom: "15px",
                        }}
                      />
                      <p className="icon-title  ml-5 text-dark">&nbsp; Email</p>
                    </a>
                  </div>
                  <WhatsappShareButton
                    // url={window.location.href}
                    url={
                      ticketDetail
                        ? `Your Event Booking ID is ${ticketDetail?.id} Click here to get QR code ${process.env.REACT_APP_BASE_URL}/${ticketDetail?.qrImage}`
                        : resTicketDetail
                        ? `Your Event Booking ID is :${resTicketDetail?.number_id},
                          Booking date: ${resTicketDetail?.booking_date},
                          Guest : ${resTicketDetail?.total_people},
                          Date : ${resTicketDetail?.booking_date},
                          Time : ${resTicketDetail?.time},
                          Email : ${resTicketDetail?.customer_email}
                          Click here to get QR code ${process.env.REACT_APP_BASE_URL}/${resTicketDetail?.qrImage}`
                        : `${window.location.href}`
                    }
                  >
                    <WhatsappIcon
                      className="icon"
                      logofillcolor="white"
                      round={true}
                      width="45px"
                    ></WhatsappIcon>
                    <p className="icon-title">Whatsapp</p>
                  </WhatsappShareButton>
                </div>
              </div>
              <div className="copy-box">
                <input type="text" id="copyText" value={window.location.href} />
                <button className="copy-btn" onClick={copyText}>
                  copy
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareIconModule;
