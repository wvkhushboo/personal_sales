import React, { useState } from "react";
import { Modal, Button } from "antd";
import "./index.scss";
import { InfoCircleOutlined } from "@ant-design/icons";

function Failed() {
  const [isModalVisible, setIsModalVisible] = useState(true);
  const handleOk = () => {
    setIsModalVisible(false);
  };
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  return (
    <div className="failedContainer">
      <Modal
        footer={[
          <Button
            className="failedBtn"
            key="submit"
            type="primary"
            onClick={handleOk}
          >
            OK
          </Button>,
        ]}
        width="300px"
        height="150px"
        style={{ textAlign: "center" }}
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        closeIcon=" "
      >
        <InfoCircleOutlined className="failedIcon" />
        <h4 style={{ marginTop: "19px", fontWeight: "bold" }}>
          Payment Cancelled{" "}
        </h4>
        <p style={{ marginBottom: "-1em", fontWeight: "bold" }}>
          Please Try Again
        </p>
      </Modal>
    </div>
  );
}

export default Failed;
