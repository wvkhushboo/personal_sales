import React from "react";
import { useSelector } from "react-redux";

import { useState } from "react";
import "./style.scss";
import { useNavigate } from "react-router-dom";

export default function MenuFloatingBar() {
  const [loading, setLoading] = useState(false);

  //   const dispatch = useDispatch();

  const menuCart = useSelector((state) => state.menuCart);

  const navigate = useNavigate();

  const handleClick = () => {
    setLoading(true);

    setTimeout(() => {
      navigate("/menu-checkout");
      setLoading(false);
    }, 1000);
  };

  return (
    <>
      {menuCart?.total > 0 && (
        <div className="ticketFloatingBarComponent">
          <div className={`eventBooking booked show`} onClick={handleClick}>
            <div className="add_order">
              <div className="row">
                <div className="col-6">
                  <h6 className="fw-bold">
                    <span className="floatingQualtity">
                      {menuCart?.addedItems.length}
                    </span>{" "}
                    Checkout{" "}
                    <span
                      className={`spinner-border spinner-border-sm ms-2 ${
                        loading ? "" : "d-none"
                      }`}
                      role="status"
                      aria-hidden="true"
                    ></span>
                  </h6>
                </div>
                <div className="text-right col-6">
                  <h6 className="fw-bold">
                    Total: € {parseFloat(menuCart?.total).toFixed(2)}{" "}
                    <i className="fa fa-eur mr-2" aria-hidden="true"></i>
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
