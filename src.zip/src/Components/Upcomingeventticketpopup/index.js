import React, { useEffect, useState } from "react";
import "./style.scss";
import axios from "axios";
import {
  errorNotify,
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication";
import moment from "moment";
import TicketFloatingBar from "../Ticketfloatingbar";
import { useDispatch, useSelector } from "react-redux";
import { eventticketquantityaction } from "../../Redux/Actions/eventticketquantityAction";
import { floatingbardata } from "../../Redux/Actions/floatingnbarAction";
import { floatingbardataquantity } from "../../Redux/Actions/floatingbarquantity";
import { restaurantIdAction } from "../../Redux/Actions/restaurantIdAction";
import { Carousel } from "react-bootstrap";
import { ticketSingleEventsAction } from "../../Redux/Actions/ticketSingleEventAction";
import Dummuimg from "../../Assets/Images/placeHolder.jpg";
import ReplaceCartPopup from "../ReplaceCartPopup";
import { updateSelectedTickets } from "../../Redux/Actions/eventTicketActions";
import { getTicketType } from "../../helpers/getTicketType";
import { useNavigate } from "react-router-dom";

export default function UpcomingTicketEventPopup(props) {
  const { selectedEvent } = props;
  const [restaurantDetail, setRestaurantDetail] = useState([]);
  const [counts, setCounts] = useState([]);
  const [totalArray, setTotalArray] = useState([]);
  const [totalQuantity, setTotalQuantity] = useState([]);
  const [viewModal, setViewModal] = useState(false);
  //eslint-disable-next-line
  const [placeArea, setPlaceArea] = useState(false);
  const [isReadMore, setIsReadMore] = useState(true);
  const toggleReadMore = () => {
    setIsReadMore(!isReadMore);
  };
  // const [selectedTickets, updateSelectedTickets] = useState({});
  const { selectedTickets } = useSelector(
    (state) => state?.eventticketformdatareducer
  );

  // console.log(selectedTickets);

  // console.log(selectedTickets);
  const [replaceCartPopup, setReplaceCartPopup] = useState(false);

  // read more read less ends
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // dispatch(updateSelectedTickets({}));

  useEffect(() => {
    selectedEvent?.id &&
      axios
        .get(
          `${process.env.REACT_APP_API_URL}/get-event-details/${selectedEvent?.id}`
        )
        .then((res) => {
          if (res.data.status === "200") {
            setRestaurantDetail(res?.data?.data?.event_detatils);
            console.log(res?.data?.data?.event_detatils);
            setCounts(res?.data?.data?.event_detatils?.price);
          } else if (res.data.status === "201") {
            errorNotify(res?.data?.message);
          } else {
            internalErrorNotify();
          }
        })
        .catch((error) => {
          if (error?.response?.status === 401) {
            unauthenticatedNotify(navigate);
          } else {
            internalErrorNotify();
          }
        });
  }, [selectedEvent?.id, navigate]);

  // console.log(restaurantDetail);

  // console.log(restaurantDetail);

  const decrementCount = (data) => {
    var dummyArray = [...counts];
    const ix = dummyArray.findIndex(
      (res) => res.person_type === data.person_type
    );
    if (dummyArray[ix].intital_quantity !== 0) {
      dummyArray[ix].ticket_quantity = dummyArray[ix].ticket_quantity -= 1;
      dummyArray[ix].intital_quantity = data.intital_quantity -= 1;
      if (Object.keys(dummyArray[ix]).includes("amount")) {
        dummyArray[ix].amount =
          dummyArray[ix].intital_quantity * data.sales_price;
      } else {
        dummyArray[ix].amount = data?.sales_price - data?.sales_price;
      }
    }
    setCounts(dummyArray);
  };

  const incrementCount = (data) => {
    var dummyArray = [...counts];
    const ix = dummyArray.findIndex(
      (res) => res.person_type === data.person_type
    );
    dummyArray[ix].ticket_quantity = dummyArray[ix].ticket_quantity += 1;
    dummyArray[ix].intital_quantity = data.intital_quantity += 1;
    dummyArray[ix].amount =
      selectedEvent.price[ix].sales_price * dummyArray[ix].intital_quantity;
    setCounts(dummyArray);
  };

  useEffect(() => {
    if (counts.length) {
      const arr = [];
      const quantity = [];
      counts.forEach((item) => {
        arr.push(item.amount === undefined ? item.sales_price : item.amount);
        quantity.push(item.intital_quantity);
      });
      setTotalArray(arr);
      setTotalQuantity(quantity);
      // console.log(counts);
      dispatch(eventticketquantityaction(counts));
    }

    //eslint-disable-next-line
  }, [counts]);

  const orderFunction = () => {
    if (
      selectedTickets?.hasOwnProperty("totalArray") &&
      selectedTickets?.hasOwnProperty("totalQuantity") &&
      selectedTickets?.eventID !== selectedEvent?.id
    ) {
      setReplaceCartPopup(true);
    } else {
      dispatch(
        updateSelectedTickets({
          totalArray,
          totalQuantity,
          eventID: selectedEvent?.id,
        })
      );
    }
    dispatch(ticketSingleEventsAction(selectedEvent?.id));
    if (totalArray.reduce((a, b) => a + b, 0) === 0) {
    } else {
      setViewModal(true);
      document.body.classList.remove("modal-open");
      props.setShow("");
    }
    dispatch(floatingbardata(totalArray));
    dispatch(floatingbardataquantity(totalQuantity));
  };

  const closeModal = () => {
    document.body.classList.remove("modal-open");
    props.setShow("");
  };

  useEffect(() => {
    placeArea && dispatch(restaurantIdAction(placeArea));
  }, [placeArea, dispatch]);

  let privacyPolicyLink = selectedEvent?.privacy_policy_link;

  return (
    <div className="upcomingTicketEventPopupComponent">
      <div
        className={`modal fade ${props.show} `}
        style={{ opacity: "1" }}
        id="myModal"
      >
        <div
          className="modal-dialog"
          style={{
            position: "absolute",
            left: "50%",
            top: "50%",
            width: "90%",
            margin: "0px auto",
            transform: "translate(-50%, -50%)",
          }}
        >
          <div
            className="modal-content"
            style={{ width: "100%", backgroundColor: "white" }}
          >
            <div
              className="modal-body"
              style={{
                position: "relative",
                flex: "1 1 auto",
                padding: "1rem",
                display: "block",
                justifyContent: "flex-start",
              }}
            >
              <div className="closeBtn">
                <button
                  type="button"
                  className="close mb-2"
                  data-dismiss="modal"
                  onClick={() => closeModal()}
                >
                  &times;
                </button>
              </div>
              <div className="main_category_modalSection">
                <Carousel controls={false}>
                  {restaurantDetail.hasOwnProperty("event_image_array") ? (
                    restaurantDetail?.event_image_array &&
                    restaurantDetail?.event_image_array?.map((i, index) => (
                      <Carousel.Item key={index}>
                        <img
                          className="d-block w-100"
                          src={
                            process.env.REACT_APP_API_URL.slice(0, -3) +
                            i?.event_image_path
                          }
                          alt="slide"
                        />
                      </Carousel.Item>
                    ))
                  ) : (
                    <img src={Dummuimg} className="trackImg" alt="trackImg" />
                  )}
                </Carousel>
              </div>
              <div className="category_details flex-nowrap">
                <div className="restaurant_info">
                  <h4>
                    <strong>{selectedEvent?.ticket_name}</strong>
                    <span
                      style={{
                        fontSize: "10px",
                        fontWeight: "initial",
                        fontStyle: "italic",
                      }}
                      className="ml-1 font-normal"
                    >
                      (
                      {getTicketType(
                        selectedEvent?.ticket_type_id,
                        selectedEvent?.ticket_use_time
                      )}
                      )
                    </span>
                  </h4>
                  <p></p>
                  <article>
                    <i
                      className="fa fa-map-marker"
                      style={{ marginTop: "4px" }}
                      aria-hidden="true"
                    ></i>
                    <p>
                      {restaurantDetail?.event_place &&
                        restaurantDetail?.event_place[0]?.address}
                    </p>
                  </article>
                  {/* <article>
                    <i
                      className="fa fa-thumb-tack"
                      style={{ marginTop: "4px" }}
                      aria-hidden="true"
                    ></i>
                    <p>
                      {restaurantDetail?.event_place &&
                        restaurantDetail?.event_place[0]?.city}
                    </p>
                  </article> */}
                  <article>
                    <i
                      className="fa fa-phone"
                      style={{ marginTop: "6px" }}
                      aria-hidden="true"
                    ></i>

                    <p>{selectedEvent?.event_contact || "N/A"}</p>
                  </article>
                  <article>
                    <i
                      className="fa fa-calendar"
                      style={{ marginTop: "4px" }}
                      aria-hidden="true"
                    ></i>
                    <span>
                      {moment(selectedEvent?.event_start_date).format(
                        "DD MMM YYYY"
                      )}{" "}
                      -
                    </span>

                    <span className="ml-2">
                      {moment(selectedEvent?.event_end_date).format(
                        "DD MMM YYYY"
                      )}
                    </span>
                  </article>
                  <article>
                    <i
                      className="fa fa-clock-o"
                      style={{ marginTop: "4px" }}
                      aria-hidden="true"
                    ></i>

                    <span>{selectedEvent?.event_start_time} -</span>
                    <span className="ml-2">
                      {selectedEvent?.event_end_time}
                    </span>
                  </article>
                </div>
                {props?.show && (
                  <div className="text-end">
                    <div className="text-dark">
                      {!selectedEvent?.price[0] ||
                      selectedEvent?.price[0]?.ticket_price === 0 ? (
                        <span className="font-size-16 text-success fw-bold">
                          Free-Entry
                        </span>
                      ) : selectedEvent.discount_percentage !== "0.00" ? (
                        <del className="text-danger fw-bold font-size-16">
                          € {selectedEvent?.price[0]?.ticket_price.toFixed(2)}
                        </del>
                      ) : (
                        <span className="font-size-16 fw-bold">
                          € {selectedEvent?.price[0]?.sales_price.toFixed(2)}
                        </span>
                      )}
                    </div>
                    <span>
                      <div className="text-right">
                        <div>
                          {selectedEvent.discount_percentage !== "0.00" && (
                            <span className="text-success font-size">
                              ({selectedEvent.discount_percentage}% OFF)
                            </span>
                          )}
                        </div>
                      </div>
                      &nbsp;
                      <span className="font-size-16 fw-bold">
                        {selectedEvent?.price[0] &&
                          selectedEvent?.price[0]?.ticket_price !== 0 &&
                          selectedEvent.discount_percentage !== "0.00" &&
                          `€ ${selectedEvent?.price[0]?.sales_price.toFixed(
                            2
                          )}`}
                      </span>
                    </span>
                  </div>
                )}
              </div>

              <div className="highlists_info">
                <h4 className=""> Highlights </h4>
                {/* DO NOT REMOVE THIS COMMENTED CODE */}
                {/* <p className="restaurant-desc-container ">
                  {restaurantDetail?.description?.length > 230 ? (
                    <input type="checkbox" id="toggle-input" />
                  ) : null}

                  <span className="ellipsis">
                    {restaurantDetail?.description}
                  </span>
                  {restaurantDetail?.description?.length > 230 ? (
                    <label id="toggle-label" for="toggle-input"></label>
                  ) : null}
                </p> */}
                {selectedEvent?.description?.length < 230 ? (
                  selectedEvent?.description
                ) : (
                  <p className="text">
                    {isReadMore
                      ? selectedEvent?.description?.slice(0, 231)
                      : selectedEvent?.description}
                    <span onClick={toggleReadMore} className="read-or-hide">
                      {isReadMore ? "...Read More" : " Show Less"}
                    </span>
                  </p>
                )}
                <div
                  style={{
                    marginTop: "2%",
                  }}
                >
                  <a
                    className="linkColor"
                    style={{ color: "#526AF3" }}
                    href={`${privacyPolicyLink}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {}
                    Privacy Policy
                  </a>
                </div>
              </div>
              <div className="order_evnt_lg">
                <div className="event-order">
                  <h4> Select number of tickets </h4>
                  {counts?.map((item, index) => (
                    <div className="main_order_section row mb-2" key={index}>
                      <div className="col-sm-4 col-3">
                        <div>
                          <h5> {item?.person_type} </h5>
                        </div>
                      </div>
                      <div className="col-sm-4 col-6">
                        <div className="categoryCount">
                          <div className="inputNumwithbtn text-center">
                            <button
                              className="num-btn num_min"
                              onClick={() => decrementCount(item)}
                            >
                              -
                            </button>

                            <span className="p-3 fs-6">
                              {item?.intital_quantity}
                            </span>
                            <button
                              className="num-btn num_plus"
                              onClick={() => incrementCount(item)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="col-sm-4 col-3">
                        <div className="text-right">
                          <h5>
                            {" "}
                            <i className="fa fa-eur" aria-hidden="true"></i>
                            &nbsp;
                            {parseFloat(
                              Object.keys(item).includes("amount")
                                ? item?.amount
                                : item?.sales_price *
                                    parseInt(item?.intital_quantity)
                            ).toFixed(2)}{" "}
                          </h5>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="eventBooking">
                  <div
                    className="add_order"
                    data-dismiss="modal"
                    onClick={() => orderFunction()}
                  >
                    <h6 style={{ color: "#fff !important" }}> Add to order </h6>
                    <h6>
                      <i className="fa fa-eur" aria-hidden="true"></i>&nbsp;
                      {parseFloat(
                        totalArray.reduce((a, b) => a + b, 0)
                      ).toFixed(2)}{" "}
                    </h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <TicketFloatingBar
        totalQuantity={totalQuantity}
        totalArray={totalArray}
        viewModal={viewModal}
        selectedTickets={selectedTickets}
        ticketCounts={counts}
      />
      {replaceCartPopup && (
        <ReplaceCartPopup
          totalArray={totalArray}
          totalQuantity={totalQuantity}
          updateSelectedTickets={updateSelectedTickets}
          setReplaceCartPopup={setReplaceCartPopup}
          eventID={selectedEvent?.id}
        />
      )}
    </div>
  );
}
