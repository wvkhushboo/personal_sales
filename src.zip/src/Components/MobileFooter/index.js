import React from "react";
import { NavLink } from "react-router-dom";
import { NavItem } from "react-bootstrap";
import "./style.scss";

// import store from "store";
// import homeimg from "../../Assets/Images/home.svg";
// import homeimg1 from "../../Assets/Images/home1.svg";
import event2 from "../../Assets/Images/event2.svg";
import event1 from "../../Assets/Images/event1.svg";
import account from "../../Assets/Images/account-w.svg";
import account1 from "../../Assets/Images/account-w1.svg";
import restaurants from "../../Assets/Images/restaurants.svg";
import restaurants1 from "../../Assets/Images/restaurants1.svg";
import order from "../../Assets/Images/order.svg";
import order1 from "../../Assets/Images/order1.svg";

const MobileFooter = () => {
  return (
    <>
      <div className="mobileFooter">
        <footer className="footer" id="mainFooter">
          <div>
            <NavItem>
              <ul className="footerNav text-center">
                <li
                  className={
                    window.location.pathname ===
                    `${process.env.PUBLIC_URL}/sell-tickets`
                      ? "footerLi active"
                      : "footerLi"
                  }
                >
                  <NavLink to="/sell-tickets">
                    <img
                      src={
                        window.location.pathname ===
                        `${process.env.PUBLIC_URL}/sell-tickets`
                          ? event1
                          : event2
                      }
                      alt="Event"
                    />
                    <span>Event</span>
                  </NavLink>
                </li>
                <li
                  className={
                    window.location.pathname ===
                    `${process.env.PUBLIC_URL}/sell-table-booking`
                      ? "footerLi active"
                      : "footerLi"
                  }
                >
                  <NavLink to="/sell-table-booking">
                    <img
                      src={
                        window.location.pathname ===
                        `${process.env.PUBLIC_URL}/sell-table-booking`
                          ? restaurants1
                          : restaurants
                      }
                      alt="Restaurants"
                    />
                    <span>Restaurants</span>
                  </NavLink>
                </li>
                {/* <li
                  className={
                    window.location.pathname ===
                    `${process.env.PUBLIC_URL}/home`
                      ? "footerLi active"
                      : "footerLi"
                  }
                >
                  <NavLink to="/home">
                    <img
                      src={
                        window.location.pathname ===
                        `${process.env.PUBLIC_URL}/home`
                          ? homeimg1
                          : homeimg
                      }
                      alt="Home"
                    />
                    <span>Home</span>
                  </NavLink>
                </li> */}

                <li
                  className={
                    window.location.pathname ===
                      `${process.env.PUBLIC_URL}/account` ||
                    window.location.pathname ===
                      `${process.env.PUBLIC_URL}/my-account` ||
                    window.location.pathname ===
                      `${process.env.PUBLIC_URL}/change-password`
                      ? "footerLi active"
                      : "footerLi"
                  }
                >
                  {/* <NavLink to={store.get("hhr_token") ? "/account" : "/"}> */}
                  <NavLink to={"/account"}>
                    <img
                      src={
                        window.location.pathname ===
                          `${process.env.PUBLIC_URL}/account` ||
                        window.location.pathname ===
                          `${process.env.PUBLIC_URL}/my-account` ||
                        window.location.pathname ===
                          `${process.env.PUBLIC_URL}/change-password`
                          ? account1
                          : account
                      }
                      alt="Account"
                    />
                  </NavLink>
                  {/* <span>{store.get("hhr_token") ? "Account" : "Sign In"}</span> */}
                  <span>{"Account"}</span>
                </li>

                <li
                  className={
                    window.location.pathname ===
                    `${process.env.PUBLIC_URL}/my-commission`
                      ? "footerLi active"
                      : "footerLi"
                  }
                >
                  <NavLink to="/my-commission">
                    <img
                      src={
                        window.location.pathname ===
                        `${process.env.PUBLIC_URL}/my-commission`
                          ? order1
                          : order
                      }
                      alt="order"
                    />
                    <span>Order</span>
                  </NavLink>
                </li>
              </ul>
            </NavItem>
          </div>
        </footer>
      </div>
    </>
  );
};

export default MobileFooter;
