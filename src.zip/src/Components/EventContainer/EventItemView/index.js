import React from "react";
import { Card, Button } from "react-bootstrap";

import "./index.css";

const EventItemView = ({ data, onClick }) => {
  return (
    <>
      <div className="mt-3 mb-3 EventCard" onClick={onClick}>
        <Card>
          <Card.Img variant="top" src={data.eventImg} />
          <Card.Body>
            <Card.Title>{data.eventTitle}</Card.Title>
            <div className="card-text card-address">
              <p>{data.eventDate}</p>
              <p>{data.eventAdd.line1}</p>
              <p>{data.eventAdd.line2}</p>
            </div>
          </Card.Body>
          <Card.Body className="card-price">
            <div className="card-text">
              {data.eventPrice.discount ? (
                <>
                  <p>
                    <del className="text-danger font-weight-bold font-size-16">
                      Rs. {data.eventPrice.actualPrice}
                    </del>
                  </p>
                  <p className="text-success">{`(${data.eventPrice.discount}% OFF)`}</p>
                </>
              ) : null}

              <p className="font-weight-bold">
                Rs.{" "}
                {data.eventPrice.actualPrice -
                  (data.eventPrice.actualPrice * data.eventPrice.discount) /
                    100}
              </p>
            </div>
            <Button>Book Now</Button>
          </Card.Body>
        </Card>
      </div>
    </>
  );
};

export default EventItemView;
