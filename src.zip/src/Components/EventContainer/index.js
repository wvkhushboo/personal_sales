import React from "react";
import EventItemView from "./EventItemView";

const EventContainer = ({ data, onClick }) => {
  return (
    <div className="container eventContainer">
      <div className="row">
        <div className="col-md-10" style={{ paddingBottom: "120px" }}>
          {data.map((eventData, index) => (
            <EventItemView key={index} data={eventData} onClick={onClick} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventContainer;
