import React, { useEffect, useRef } from "react";
import Navbar from "../Navbar";
import { useForm } from "react-hook-form";
import Logo from "../../Assets/Images/logo-black.png";

import "./index.css";
import { Button } from "antd-mobile";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setEmail } from "../../Redux/Actions/signInActions";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";

const Email = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
  });

  const emailInputRef = useRef(null);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const logData = JSON.parse(localStorage.getItem("Login"));

  const onSubmit = (data) => {
    dispatch(setEmail(data.email));

    navigate("/password");

    document.querySelector("#userEmail").value = "";
  };

  useEffect(() => {
    if (logData?.isAuth) {
      navigate("/account", { replace: true });
    }
  }, [navigate, logData]);

  return (
    <>
      <Navbar title="Sign In" leftIcon={<ArrowLeftIcon />} />
      <div className="container myEmailContainer">
        <div className="emailLogo text-center">
          <img src={Logo} alt="logo-black" />
        </div>

        <div className="emailForm mt-5">
          <h6 className="font-weight-bold">Sign In for Sales Person</h6>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-4">
            <div className="form-group">
              <p className="formLabel font-weight-bold">Email</p>
              <input
                id="userEmail"
                className="form-control"
                type="email"
                autoComplete="off"
                ref={emailInputRef}
                {...register("email", {
                  required: "Email is required",
                  pattern: {
                    value: RegExp(
                      "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+[.]+[.a-zA-Z]{2,8}$"
                    ),
                    message: "Invalid email address",
                  },
                  maxLength: {
                    value: 100,
                    message: "Email should be under 100 characters",
                  },
                })}
              />
              {errors.email && (
                // <span className="input-error">{errors.email.message}</span>
                <div className="alert alert-danger mt-3" role="alert">
                  {errors.email.message}
                </div>
              )}
            </div>
            <div className="mt-3">
              <Button
                block
                shape="rounded"
                type="submit"
                style={{ backgroundColor: "#526bf3", color: "white" }}
              >
                Next
              </Button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Email;
