import { Empty, Modal, Spin } from "antd";
import axios from "axios";
import React, { useEffect, useState } from "react";
import {
  errorNotify,
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication";
import MenuImage from "../../Assets/Images/menu.jpg";
import "./style.scss";

export default function MenuPopup(props) {
  const [menu, setMenu] = useState([]);
  const [selectedMenuData, setSelectedMenuData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    setLoading(true);
    const formdata = new FormData();
    formdata.append("menu_type_id", 1);
    formdata.append("restaurant_id", props.restaurant_id);

    axios
      .post(`${process.env.REACT_APP_API_URL}/get-menu-items`, formdata)
      .then((res) => {
        if (res.data.status === "200") {
          setMenu(res.data.data);
          setSelectedMenuData(res.data.data);
        } else if (res.data.status === "201") {
          errorNotify(res.data.message);
        } else {
          internalErrorNotify();
        }
        setLoading(false);
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(props.history);
        } else {
          internalErrorNotify();
        }
        setLoading(false);
      });
    //eslint-disable-next-line
  }, []);

  const decrementCount = (item, id) => {
    var testArray = [...item.menu_items];
    var dummyArray = [...menu];

    const foundId = testArray.findIndex((res) => res.id === id); // 0
    const foundMenuId = menu.findIndex(
      (res) => res.menu_category_name === item.menu_category_name // 0
    );
    if (item.menu_items[foundId].menu_count) {
      item.menu_items[foundId].menu_count =
        item.menu_items[foundId].menu_count - 1;
      item.menu_items[foundId].item_price =
        parseInt(dummyArray[foundMenuId].menu_items[foundId].base_amount) *
        item.menu_items[foundId].menu_count;
      dummyArray[foundMenuId].menu_items = item.menu_items;
      setSelectedMenuData([...dummyArray]);
      setTotalAmount(
        totalAmount -
          parseInt(dummyArray[foundMenuId].menu_items[foundId].base_amount)
      );
    }
  };

  const incrementCount = (item, id) => {
    var testArray = [...item.menu_items];
    var dummyArray = [...menu];

    const foundId = testArray.findIndex((res) => res.id === id); // 0
    const foundMenuId = menu.findIndex(
      (res) => res.menu_category_name === item.menu_category_name // 0
    );
    item.menu_items[foundId].menu_count =
      item.menu_items[foundId].menu_count + 1;
    item.menu_items[foundId].item_price =
      parseInt(dummyArray[foundMenuId].menu_items[foundId].base_amount) *
      item.menu_items[foundId].menu_count;
    dummyArray[foundMenuId].menu_items = item.menu_items;
    setSelectedMenuData([...dummyArray]);
    setTotalAmount(
      totalAmount +
        parseInt(dummyArray[foundMenuId].menu_items[foundId].base_amount)
    );
  };
  return (
    <div className="menuPopupComponent">
      <div style={{ zIndex: "10000 !important" }} className="menuPopup11">
        <Modal
          title="Select Menu"
          open={true}
          onOk={() => {
            props.setMenuPopup(false);
            props.setMenuData(selectedMenuData);
          }}
          onCancel={() => {
            props.setMenuPopup(false);
          }}
          okText="Done"
          cancelText="Cancel"
          className="menuPopup"
        >
          {loading ? (
            <div className="noMenuDiv">
              <Spin size="large" spinning={loading} tip="Loading..." />
            </div>
          ) : menu.length === 0 ? (
            <div className="noMenuDiv">
              <Empty description="No Menu Found" />
            </div>
          ) : (
            selectedMenuData?.map((menu_item, index) => (
              <div className="menus_sec" key={index}>
                <div className="container mb-20">
                  <h2 className="heading_2">{menu_item.menu_category_name}</h2>
                  <div className="col-md-12 text-right">
                    Total : {totalAmount}
                  </div>
                  <div className="row">
                    {menu_item?.menu_items.map((item, index) => (
                      <div className="col-md-4" key={index}>
                        <div className="menuCard">
                          <div className="mc_image">
                            <img
                              src={
                                item?.item_image === ""
                                  ? MenuImage
                                  : process.env.REACT_APP_BASE_URL +
                                    item?.item_image
                              }
                              alt="menu"
                              className="menuSinleImg"
                            />
                          </div>
                          <div className="mc_content">
                            <div className="mcc_left">
                              <div className="menu_nameprice">
                                <div className="menuName">{item.item_name}</div>
                              </div>
                              <div className="menu_nameprice priceDetails">
                                <h5>€ {item.sale_price.toFixed(2)}</h5>
                              </div>
                            </div>
                            <>
                              <div className="mcc_right customeBtns inputNumwithbtn">
                                <button
                                  className="num-btn num_min"
                                  onChange=""
                                  onClick={() =>
                                    decrementCount(menu_item, item.id)
                                  }
                                >
                                  -
                                </button>
                                <input type="text" value={item.menu_count} />
                                <button
                                  className="num-btn num_plus"
                                  onClick={() =>
                                    incrementCount(menu_item, item.id)
                                  }
                                >
                                  +
                                </button>
                              </div>
                            </>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))
          )}
        </Modal>
      </div>
    </div>
  );
}
