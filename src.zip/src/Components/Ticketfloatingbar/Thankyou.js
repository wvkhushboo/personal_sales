import React, { useState } from "react";
import { Modal, Button } from "antd";
import thankYouSmiley from "../../Assets/Images/Smiley.png";
import "./thankyou.scss";
import { useHistory, useLocation } from "react-router-dom";

function EventThankYou() {
  const history = useHistory();
  const [isModalVisible, setIsModalVisible] = useState(true);

  const search = useLocation().search;
  const data = new URLSearchParams(search).get("success");

  const handleOk = () => {
    history.push("/");
  };

  return (
    <div className="eventThankYouComponent">
      {data ? (
        <Modal
          className="modalBody"
          footer={[
            <Button
              className="successBtn"
              key="submit"
              type="primary"
              onClick={handleOk}
            >
              OK
            </Button>,
          ]}
          width="300px"
          height="200px"
          style={{ textAlign: "center" }}
          open={isModalVisible}
          onOk={handleOk}
        >
          <img src={thankYouSmiley} width="80px" alt="img"></img>
          <h4 style={{ marginTop: "7px", fontWeight: "bold" }}>Thank You </h4>
          <p style={{ marginBottom: "-1em", fontWeight: "bold" }}>
            Your event has been booked successfully.
          </p>
        </Modal>
      ) : (
        <Modal
          footer={[
            <Button
              className="failedBtn"
              key="submit"
              type="primary"
              onClick={handleOk}
            >
              OK
            </Button>,
          ]}
          width="300px"
          height="150px"
          style={{ textAlign: "center" }}
          visible={isModalVisible}
          onOk={handleOk}
          closeIcon=" "
        >
          <img
            src="https://media.istockphoto.com/photos/thumb-down-emoji-isolated-on-white-background-picture-id962578498?s=612x612"
            width="40%"
            height="40%"
            alt="img"
          ></img>

          <div>
            <h4 style={{ marginTop: "19px", fontWeight: "bold", color: "red" }}>
              Payment Cancelled
            </h4>
          </div>
        </Modal>
      )}
    </div>
  );
}

export default EventThankYou;
