import { loadStripe } from "@stripe/stripe-js";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import {
  errorNotify,
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication";
import { tablebookingresponsedata } from "../../Redux/Actions/tablebookingresponsedataAction";
import "./style.scss";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function TicketFloatingBar({
  history,
  selectedTickets,
  ticketCounts,
}) {
  const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_KEY);

  const [loading, setLoading] = useState(false);

  const dispatch = useDispatch();

  const ticketquantity = useSelector(
    (state) => state.eventticketquantityreducer.eventticketquantity
  );

  const navigate = useNavigate();

  // console.log(ticketquantity);

  const floatingbardata = useSelector(
    (state) => state.floatingbarReducer.floatingbardata
  );

  const ticketQuantity = useSelector(
    (state) => state.floatingbarquantityreducer.floatingbardataquantity
  );
  const eventData = useSelector(
    (state) => state.ticketSingleEventReducer.singleTicket
  );

  const handleStripeRedirection = async (sessiondata) => {
    const stripe = await stripePromise;

    const result = await stripe.redirectToCheckout({
      sessionId: sessiondata,
    });
    console.log(result);

    if (result.error) {
    }
  };

  const handleClick = () => {
    let menus_data_arr = [];
    let people_count_info = [];
    const ticket_count = parseFloat(ticketQuantity.reduce((a, b) => a + b, 0));
    const booking_amount = parseFloat(
      floatingbardata.reduce((a, b) => a + b, 0)
    );

    ticketquantity?.forEach((item) => {
      menus_data_arr.push({
        people_id: item?.person_id,
        count: item?.intital_quantity,
      });
    });

    ticketCounts?.map((tkt) => {
      for (let i = 0; i < tkt.intital_quantity; i++) {
        people_count_info = [...people_count_info, { name: tkt?.person_type }];
      }

      return people_count_info;
    });

    const formData = new FormData();

    // console.log(user_data);

    formData.append("venue_admin_id", eventData && eventData?.user_id);
    formData.append("restaurant_id", 27);
    formData.append("place_area_id", eventData?.event_place[0].place_area_id);
    // formData.append("customer_email", user_data?.email || "abc@gmail.com");
    formData.append("guest_count", ticket_count);
    formData.append("booking_amount", booking_amount);
    formData.append("event_id", eventData && eventData?.id);
    formData.append("people_price_data", JSON.stringify(menus_data_arr));
    formData.append("people_count_info", JSON.stringify(people_count_info));
    formData.append(
      "return_url",
      `${window.location.origin}${process.env.PUBLIC_URL}/event-cart/stripe-event`
    );

    setLoading(true);
    axios
      .post(`${process.env.REACT_APP_API_URL}/event-booking`, formData)
      .then((res) => {
        if (res.data.status === "200") {
          setLoading(false);
          // handleStripeRedirection(res.data.data[0].stripe_checkout_session_id);
          dispatch(tablebookingresponsedata(res.data.data));
          navigate("/event-cart/stripe-event");
        } else if (res.data.status === "201") {
          errorNotify(res.data.message);
          setLoading(false);
          //apply multiple property in a single document get method.
          document.getElementById("Error").style.cssText = `
          display:block;
          text-align:center;
          `;
        } else {
          internalErrorNotify();
          setLoading(false);
        }
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(history);
        } else {
          internalErrorNotify();
        }
      });
  };

  return (
    <>
      {selectedTickets?.totalQuantity && selectedTickets?.totalArray && (
        <div className="ticketFloatingBarComponent">
          <div className={`eventBooking booked show`} onClick={handleClick}>
            <div className="add_order">
              <div className="row">
                <div className="col-6">
                  <h6>
                    <span className="floatingQualtity">
                      {selectedTickets?.totalQuantity?.reduce(
                        (a, b) => a + b,
                        0
                      )}
                    </span>{" "}
                    Checkout{" "}
                    <span
                      className={`spinner-border spinner-border-sm ms-2 ${
                        loading ? "" : "d-none"
                      }`}
                      role="status"
                      aria-hidden="true"
                    ></span>
                  </h6>
                </div>
                <div className="text-right col-6">
                  <h6>
                    {parseFloat(
                      selectedTickets?.totalArray?.reduce((a, b) => a + b, 0)
                    ).toFixed(2)}{" "}
                    <i className="fa fa-eur mr-2" aria-hidden="true"></i>
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
