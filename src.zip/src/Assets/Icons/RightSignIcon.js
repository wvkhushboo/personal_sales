import React from 'react';

const RightSignIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='7.59'
			height='13.181'
			viewBox='0 0 7.59 13.181'
			{...props}
		>
			<path
				id='Path_1208'
				data-name='Path 1208'
				d='M6647.441,246l3.235,3.235,1.941,1.941-1.726,1.725-.539.539-1.1,1.1-1.812,1.812'
				transform='translate(-6646.027 -244.586)'
				fill='none'
				stroke='#526af3'
				strokeLinecap='round'
				strokeLinejoin='round'
				strokeWidth='2'
			/>
		</svg>
	);
};

export default RightSignIcon;
