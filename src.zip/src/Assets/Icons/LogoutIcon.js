import React from 'react';

const LogoutIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='24.38'
			height='24.298'
			viewBox='0 0 24.38 24.298'
			{...props}
		>
			<g
				id='Group_2736'
				data-name='Group 2736'
				transform='translate(-778.5 -975)'
			>
				<path
					id='Path_1041'
					data-name='Path 1041'
					d='M12.149,23.123H3.037a1.013,1.013,0,0,1-1.012-1.012V3.887A1.013,1.013,0,0,1,3.037,2.875h9.112a1.012,1.012,0,0,0,0-2.025H3.037A3.041,3.041,0,0,0,0,3.887V22.111a3.041,3.041,0,0,0,3.037,3.037h9.112a1.012,1.012,0,0,0,0-2.025Z'
					transform='translate(778.5 974.15)'
					fill='#526af3'
				/>
				<path
					id='Path_1042'
					data-name='Path 1042'
					d='M186.078,113.531l-6.155-6.074A1.012,1.012,0,0,0,178.5,108.9l4.4,4.341H171.112a1.012,1.012,0,0,0,0,2.025H182.9l-4.4,4.341a1.012,1.012,0,1,0,1.421,1.442l6.155-6.074a1.012,1.012,0,0,0,0-1.442Z'
					transform='translate(616.5 872.898)'
					fill='#526af3'
				/>
			</g>
		</svg>
	);
};

export default LogoutIcon;
