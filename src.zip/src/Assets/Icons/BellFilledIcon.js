import React from 'react';

const BellFilledIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='28.22'
			height='31.482'
			viewBox='0 0 28.22 31.482'
			{...props}
		>
			<g
				id='Group_1557'
				data-name='Group 1557'
				transform='translate(-969.211 -132)'
			>
				<g id='Alert' transform='translate(969.211 135.116)'>
					<path
						id='Path_1'
						data-name='Path 1'
						d='M26.544,24.82H17.68a3.546,3.546,0,0,1-7.091,0H1.725a1.7,1.7,0,0,1-1.6-1.241,1.893,1.893,0,0,1,.532-1.95A7.137,7.137,0,0,0,3.5,15.955V10.637a10.637,10.637,0,0,1,21.274,0v5.318a7.137,7.137,0,0,0,2.837,5.673,1.679,1.679,0,0,1,.532,1.95A1.7,1.7,0,0,1,26.544,24.82Z'
						transform='translate(-0.062)'
						fill='#526bf3'
						fill-rule='evenodd'
					/>
				</g>
				<circle
					id='Ellipse_356'
					data-name='Ellipse 356'
					cx='3'
					cy='3'
					r='3'
					transform='translate(980 132)'
					fill='#526bf3'
				/>
			</g>
		</svg>
	);
};

export default BellFilledIcon;
