import React from 'react';

const CheckIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='13.23'
			height='9.49'
			viewBox='0 0 13.23 9.49'
			{...props}
		>
			<path
				id='Path_17'
				data-name='Path 17'
				d='M8163.657,4052.471l3.328,3.328,7.074-7.075'
				transform='translate(-8162.243 -4047.31)'
				fill='none'
				stroke='#516af3'
				strokeLinecap='round'
				strokeLinejoin='round'
				strokeWidth='2'
			/>
		</svg>
	);
};

export default CheckIcon;
