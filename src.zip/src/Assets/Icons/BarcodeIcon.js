import React from 'react';

const BarcodeIcon = (props) => {
	return (
		<svg
			{...props}
			id='barcode'
			xmlns='http://www.w3.org/2000/svg'
			width='50'
			height='40'
			viewBox='0 0 50 40'
		>
			<g id='Group_2655' data-name='Group 2655' transform='translate(0 0)'>
				<g id='Group_2654' data-name='Group 2654'>
					<path
						id='Path_1373'
						data-name='Path 1373'
						d='M8.333,48H1.667A1.667,1.667,0,0,0,0,49.667v6.667a1.667,1.667,0,1,0,3.333,0v-5h5a1.667,1.667,0,1,0,0-3.333Z'
						transform='translate(0 -48)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g id='Group_2657' data-name='Group 2657' transform='translate(40 30)'>
				<g id='Group_2656' data-name='Group 2656'>
					<path
						id='Path_1374'
						data-name='Path 1374'
						d='M392.333,336a1.667,1.667,0,0,0-1.667,1.667v5h-5a1.667,1.667,0,0,0,0,3.333h6.667A1.667,1.667,0,0,0,394,344.333v-6.667A1.667,1.667,0,0,0,392.333,336Z'
						transform='translate(-384 -336)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g id='Group_2659' data-name='Group 2659' transform='translate(40 0)'>
				<g id='Group_2658' data-name='Group 2658'>
					<path
						id='Path_1375'
						data-name='Path 1375'
						d='M392.333,48h-6.667a1.667,1.667,0,0,0,0,3.333h5v5a1.667,1.667,0,0,0,3.333,0V49.667A1.667,1.667,0,0,0,392.333,48Z'
						transform='translate(-384 -48)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g id='Group_2661' data-name='Group 2661' transform='translate(0 30)'>
				<g id='Group_2660' data-name='Group 2660'>
					<path
						id='Path_1376'
						data-name='Path 1376'
						d='M8.333,342.667h-5v-5a1.667,1.667,0,0,0-3.333,0v6.667A1.667,1.667,0,0,0,1.667,346H8.333a1.667,1.667,0,0,0,0-3.333Z'
						transform='translate(0 -336)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2663'
				data-name='Group 2663'
				transform='translate(7.408 7.963)'
			>
				<g id='Group_2662' data-name='Group 2662' transform='translate(0 0)'>
					<rect
						id='Rectangle_1936'
						data-name='Rectangle 1936'
						width='3'
						height='25'
						transform='translate(-0.407 0.037)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2665'
				data-name='Group 2665'
				transform='translate(12.038 7.963)'
			>
				<g id='Group_2664' data-name='Group 2664' transform='translate(0 0)'>
					<rect
						id='Rectangle_1937'
						data-name='Rectangle 1937'
						width='6'
						height='19'
						transform='translate(-0.038 0.037)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2667'
				data-name='Group 2667'
				transform='translate(20.37 7.963)'
			>
				<g id='Group_2666' data-name='Group 2666' transform='translate(0 0)'>
					<rect
						id='Rectangle_1938'
						data-name='Rectangle 1938'
						width='2'
						height='19'
						transform='translate(-0.37 0.037)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2669'
				data-name='Group 2669'
				transform='translate(27.778 7.963)'
			>
				<g id='Group_2668' data-name='Group 2668' transform='translate(0 0)'>
					<rect
						id='Rectangle_1939'
						data-name='Rectangle 1939'
						width='2'
						height='25'
						transform='translate(0.221 0.037)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2671'
				data-name='Group 2671'
				transform='translate(32.408 7.963)'
			>
				<g id='Group_2670' data-name='Group 2670' transform='translate(0 0)'>
					<rect
						id='Rectangle_1940'
						data-name='Rectangle 1940'
						width='5'
						height='19'
						transform='translate(-0.408 0.037)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2673'
				data-name='Group 2673'
				transform='translate(39.814 7.963)'
			>
				<g id='Group_2672' data-name='Group 2672' transform='translate(0 0)'>
					<rect
						id='Rectangle_1941'
						data-name='Rectangle 1941'
						width='3'
						height='25'
						transform='translate(0.185 0.037)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2675'
				data-name='Group 2675'
				transform='translate(12.038 30.185)'
			>
				<g id='Group_2674' data-name='Group 2674' transform='translate(0 0)'>
					<rect
						id='Rectangle_1942'
						data-name='Rectangle 1942'
						width='6'
						height='2'
						transform='translate(-0.038 -0.186)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2677'
				data-name='Group 2677'
				transform='translate(20.37 30.185)'
			>
				<g id='Group_2676' data-name='Group 2676' transform='translate(0 0)'>
					<rect
						id='Rectangle_1943'
						data-name='Rectangle 1943'
						width='2'
						height='2'
						transform='translate(-0.37 -0.186)'
						fill='#526bf3'
					/>
				</g>
			</g>
			<g
				id='Group_2679'
				data-name='Group 2679'
				transform='translate(32.408 30.185)'
			>
				<g id='Group_2678' data-name='Group 2678' transform='translate(0 0)'>
					<rect
						id='Rectangle_1944'
						data-name='Rectangle 1944'
						width='5'
						height='2'
						transform='translate(-0.408 -0.186)'
						fill='#526bf3'
					/>
				</g>
			</g>
		</svg>
	);
};

export default BarcodeIcon;
