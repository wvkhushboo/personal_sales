import React from 'react';

const FoodMenuIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='40.793'
			height='40'
			viewBox='0 0 40.793 40'
			{...props}
		>
			<g
				id='Group_2336'
				data-name='Group 2336'
				transform='translate(-976 -213.07)'
			>
				<g id='food' transform='translate(976 210.153)'>
					<path
						id='Path_1153'
						data-name='Path 1153'
						d='M85.765,45.214a3.614,3.614,0,0,1-.475-.686,11.982,11.982,0,1,1-.3-2.8l1.094-8.064.025-.181A17.045,17.045,0,0,0,62.58,31.3v3.88a6.578,6.578,0,0,1-3.08,5.555V54.318a17.039,17.039,0,0,0,27.877-.65v-7.4A3.637,3.637,0,0,1,85.765,45.214Z'
						transform='translate(-51.648 -21.288)'
						fill='#526bf3'
					/>
					<path
						id='Path_1154'
						data-name='Path 1154'
						d='M96.43,78.318a10.028,10.028,0,1,0,10.028,10.028A10.039,10.039,0,0,0,96.43,78.318Z'
						transform='translate(-74.74 -65.227)'
						fill='#526bf3'
					/>
					<path
						id='Path_1155'
						data-name='Path 1155'
						d='M265.3,4.488a1.583,1.583,0,0,0-3.15-.209L259.84,21.341a1.564,1.564,0,0,0,.377,1.243,1.587,1.587,0,0,0,1.191.537h.928v18.3a1.506,1.506,0,0,0,3.011,0Z'
						transform='translate(-224.554)'
						fill='#526bf3'
					/>
					<path
						id='Path_1156'
						data-name='Path 1156'
						d='M9.171,10.436a1.027,1.027,0,0,0-2.053,0v5.639H5.612V10.436a1.027,1.027,0,0,0-2.053,0v5.639H2.053V10.436a1.027,1.027,0,0,0-2.053,0V19.63a4.562,4.562,0,0,0,3.08,4.3v23.1a1.506,1.506,0,0,0,3.011,0v-23.1a4.562,4.562,0,0,0,3.08-4.3Z'
						transform='translate(0 -5.61)'
						fill='#526bf3'
					/>
				</g>
			</g>
		</svg>
	);
};

export default FoodMenuIcon;
