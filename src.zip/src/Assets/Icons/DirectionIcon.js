import React from 'react';

const DirectionIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='16.376'
			height='20.156'
			viewBox='0 0 16.376 20.156'
		>
			<path
				id='Path_1248'
				data-name='Path 1248'
				d='M54.938,3.78h1.89V.631A.63.63,0,0,1,57.85.138l6.3,5.039a.631.631,0,0,1,0,.985L57.85,11.2a.63.63,0,0,1-1.023-.493V7.559h-1.89a3.153,3.153,0,0,0-3.149,3.149v9.448H48.009V10.709A6.937,6.937,0,0,1,54.938,3.78Z'
				transform='translate(-48.009)'
				fill='#fff'
			/>
		</svg>
	);
};

export default DirectionIcon;
