import React from 'react';

const ShareIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='18.377'
			height='19.602'
			viewBox='0 0 18.377 19.602'
		>
			<g id='share' transform='translate(-16)'>
				<g id='Group_1080' data-name='Group 1080' transform='translate(16)'>
					<path
						id='Path_754'
						data-name='Path 754'
						d='M30.931,12.711a3.443,3.443,0,0,0-2.771,1.4l-5.409-2.764a3.446,3.446,0,0,0-.112-2.264l5.669-3.406a3.432,3.432,0,1,0-.589-.986L22.036,8.106a3.445,3.445,0,1,0,.211,4.273l5.393,2.756a3.446,3.446,0,1,0,3.291-2.424Zm0-11.562a2.3,2.3,0,1,1-2.3,2.3A2.3,2.3,0,0,1,30.931,1.149ZM19.446,12.672a2.3,2.3,0,1,1,2.3-2.3A2.3,2.3,0,0,1,19.446,12.672Zm11.486,5.781a2.3,2.3,0,1,1,2.3-2.3A2.3,2.3,0,0,1,30.931,18.454Z'
						transform='translate(-16)'
						fill='currentColor'
					strokeWidth='0.5'
					/>
				</g>
			</g>
		</svg> 
	);
};

export default ShareIcon;
