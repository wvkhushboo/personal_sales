import React from 'react';

const CopyIcon = () => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			xmlnsXlink='http://www.w3.org/1999/xlink'
			width='21.083'
			height='20.193'
			viewBox='0 0 21.083 20.193'
		>
			<defs>
				<filter
					id='Path_1259'
					x='-9'
					y='-6'
					width='39.083'
					height='38.193'
					filterUnits='userSpaceOnUse'
				>
					<feOffset dy='3' input='SourceAlpha' />
					<feGaussianBlur stdDeviation='3' result='blur' />
					<feFlood flood-opacity='0.161' />
					<feComposite operator='in' in2='blur' />
					<feComposite in='SourceGraphic' />
				</filter>
				<clipPath id='clipPath'>
					<g transform='matrix(1, 0, 0, 1, 0, 0)' filter='url(#Path_1259)'>
						<path
							id='Path_1259-2'
							data-name='Path 1259'
							d='M20.614,0H.469A.469.469,0,0,0,0,.469V19.724a.469.469,0,0,0,.469.469H20.614a.469.469,0,0,0,.469-.469V.469A.469.469,0,0,0,20.614,0Z'
							transform='translate(0)'
							fill='#516af3'
						/>
					</g>
				</clipPath>
			</defs>
			<g
				id='Mask_Group_90'
				data-name='Mask Group 90'
				transform='translate(0)'
				clipPath='url(#clipPath)'
			>
				<path
					id='copy'
					d='M6.31,20.193h7.533A3.159,3.159,0,0,0,17,17.037V6.35a3.159,3.159,0,0,0-3.155-3.155H6.31A3.159,3.159,0,0,0,3.155,6.35V17.037A3.159,3.159,0,0,0,6.31,20.193Zm7.533-15.42A1.579,1.579,0,0,1,15.421,6.35V17.037a1.579,1.579,0,0,1-1.578,1.578H6.31a1.579,1.579,0,0,1-1.578-1.578V6.35A1.579,1.579,0,0,1,6.31,4.772ZM0,15.066V3.155A3.159,3.159,0,0,1,3.155,0H11.91a.789.789,0,1,1,0,1.578H3.155A1.579,1.579,0,0,0,1.578,3.155v11.91a.789.789,0,0,1-1.578,0Zm0,0'
					transform='translate(2.043 0)'
					fill='#516af3'
				/>
			</g>
		</svg>
	);
};

export default CopyIcon;
