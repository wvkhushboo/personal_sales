import React from 'react';

const PlusIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='20'
			height='20'
			viewBox='0 0 20 20'
		>
			<g
				id='Group_2230'
				data-name='Group 2230'
				transform='translate(-260 -403)'
			>
				<g
					id='Ellipse_226'
					data-name='Ellipse 226'
					transform='translate(260 403)'
					fill='none'
					stroke='#fff'
					strokeWidth='1'
				>
					<circle cx='10' cy='10' r='10' stroke='none' />
					<circle cx='10' cy='10' r='9.5' fill='none' />
				</g>
				<g id='Group_2736' data-name='Group 2736'>
					<path
						id='Path_725'
						data-name='Path 725'
						d='M0,0H1V8H0Z'
						transform='translate(269.5 409)'
						fill='#fff'
					/>
					<rect
						id='Rectangle_3'
						data-name='Rectangle 3'
						width='1'
						height='8'
						transform='translate(274 412.5) rotate(90)'
						fill='#fff'
					/>
				</g>
			</g>
		</svg>
	);
};

export default PlusIcon;
