import React from 'react';

const TicketIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='24.001'
			height='24.001'
			viewBox='0 0 24.001 24.001'
			{...props}
		>
			<g
				id='Group_2738'
				data-name='Group 2738'
				transform='translate(-778.5 -795)'
			>
				<path
					id='Path_702'
					data-name='Path 702'
					d='M21.033,6.011l-.5.5a2.151,2.151,0,0,1-3.042-3.042l.5-.5L15.022,0,0,15.022l2.968,2.968.5-.5a2.151,2.151,0,0,1,3.042,3.042l-.5.5L8.979,24,24,8.979ZM7.951,20.984A3.559,3.559,0,0,0,3.017,16.05L1.989,15.022,15.022,1.989,16.05,3.017a3.559,3.559,0,0,0,4.934,4.934l1.028,1.028L8.979,22.012Z'
					transform='translate(778.5 795)'
					fill='#526af3'
				/>
				<rect
					id='Rectangle_1523'
					data-name='Rectangle 1523'
					width='1.407'
					height='1.412'
					transform='translate(791.52 804.982) rotate(-45)'
					fill='#526af3'
				/>
				<rect
					id='Rectangle_1524'
					data-name='Rectangle 1524'
					width='1.407'
					height='1.412'
					transform='translate(789.523 802.984) rotate(-45)'
					fill='#526af3'
				/>
				<rect
					id='Rectangle_1525'
					data-name='Rectangle 1525'
					width='1.407'
					height='1.412'
					transform='translate(793.518 806.98) rotate(-45)'
					fill='#526af3'
				/>
			</g>
		</svg>
	);
};

export default TicketIcon;
