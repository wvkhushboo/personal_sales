import React from 'react';

const MailIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='22.187'
			height='16.64'
			viewBox='0 0 22.187 16.64'
		>
			<path
				id='Path_50'
				data-name='Path 50'
				d='M19.414,2.773H2.773l8.32,6.933ZM0,2.773A2.782,2.782,0,0,1,2.773,0h16.64a2.782,2.782,0,0,1,2.773,2.773V13.867a2.782,2.782,0,0,1-2.773,2.773H2.773A2.782,2.782,0,0,1,0,13.867Z'
				fill='#526af3'
				fill-rule='evenodd'
			/>
		</svg>
	);
};

export default MailIcon;
