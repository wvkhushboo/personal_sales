import React from 'react';

const LanguageIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='33.45'
			height='30.409'
			viewBox='0 0 33.45 30.409'
		>
			<g id='translate' transform='translate(0 -21.333)'>
				<g
					id='Group_2276'
					data-name='Group 2276'
					transform='translate(0 21.333)'
				>
					<g id='Group_2275' data-name='Group 2275'>
						<path
							id='Path_1245'
							data-name='Path 1245'
							d='M18.048,41.213h0L14.186,37.4l.046-.046a26.638,26.638,0,0,0,5.641-9.929h4.455V24.374H13.684V21.333H10.643v3.041H0V27.4H16.983a24.014,24.014,0,0,1-4.82,8.15,23.977,23.977,0,0,1-3.512-5.094H5.61a26.7,26.7,0,0,0,4.531,6.933L2.41,45.029l2.151,2.151,7.6-7.6,4.729,4.729Z'
							transform='translate(0 -21.333)'
							fill='#fff'
						/>
						<path
							id='Path_1246'
							data-name='Path 1246'
							d='M244.549,192h-3.041l-6.842,18.245h3.041l1.711-4.561h7.222l1.711,4.561h3.041Zm-3.991,10.643,2.471-6.591,2.471,6.591Z'
							transform='translate(-217.941 -179.836)'
							fill='#fff'
						/>
					</g>
				</g>
			</g>
		</svg>
	);
};

export default LanguageIcon;
