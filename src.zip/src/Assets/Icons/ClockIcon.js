import React from 'react';

const ClockIcon = (props) => {
	return (
		<svg {...props} xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'>
			<circle
				id='secondary'
				cx={12}
				cy={12}
				r={9}
				style={{ fill: 'rgb(255, 255, 255)', strokeWidth: 2 }}
			/>
			<path
				id='primary'
				d='M21,12a9,9,0,1,1-9-9A9,9,0,0,1,21,12ZM12,7v5l2,3'
				style={{
					fill: 'none',
					stroke: 'rgb(82, 106, 243)',
					strokeLinecap: 'round',
					strokeLinejoin: 'round',
					strokeWidth: 2,
				}}
			/>
		</svg>
	);
};

export default ClockIcon;
