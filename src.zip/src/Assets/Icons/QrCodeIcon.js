import React from 'react';

const QrCodeIcon = (props) => {
	return (
		<svg
			{...props}
			id='qr-code'
			xmlns='http://www.w3.org/2000/svg'
			width='50'
			height='50'
			viewBox='0 0 50 50'
		>
			<g id='Group_2680' data-name='Group 2680' transform='translate(31.885 0)'>
				<path
					id='Path_1377'
					data-name='Path 1377'
					d='M31.336,18.117a2.083,2.083,0,0,1-2.083-2.083V6.158a1.994,1.994,0,0,0-1.99-1.992H17.388a2.083,2.083,0,0,1,0-4.167h9.875A6.163,6.163,0,0,1,33.42,6.158v9.875A2.083,2.083,0,0,1,31.336,18.117Z'
					transform='translate(-15.305 0)'
					fill='#526bf3'
				/>
			</g>
			<g id='Group_2681' data-name='Group 2681'>
				<path
					id='Path_1378'
					data-name='Path 1378'
					d='M2.083,18.117A2.083,2.083,0,0,1,0,16.033V6.158A6.163,6.163,0,0,1,6.156,0h9.875a2.083,2.083,0,1,1,0,4.167H6.156a1.994,1.994,0,0,0-1.99,1.992v9.875A2.083,2.083,0,0,1,2.083,18.117Z'
					transform='translate(0 0)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2682'
				data-name='Group 2682'
				transform='translate(31.885 31.883)'
			>
				<path
					id='Path_1379'
					data-name='Path 1379'
					d='M27.263,33.421H17.388a2.083,2.083,0,0,1,0-4.167h9.875a1.994,1.994,0,0,0,1.99-1.992V17.387a2.083,2.083,0,0,1,4.167,0v9.875A6.163,6.163,0,0,1,27.263,33.421Z'
					transform='translate(-15.305 -15.304)'
					fill='#526bf3'
				/>
			</g>
			<g id='Group_2683' data-name='Group 2683' transform='translate(0 31.883)'>
				<path
					id='Path_1380'
					data-name='Path 1380'
					d='M16.031,33.421H6.156A6.163,6.163,0,0,1,0,27.262V17.387a2.083,2.083,0,0,1,4.167,0v9.875a1.994,1.994,0,0,0,1.99,1.992h9.875a2.083,2.083,0,1,1,0,4.167Z'
					transform='translate(0 -15.304)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2684'
				data-name='Group 2684'
				transform='translate(7.292 7.292)'
			>
				<path
					id='Path_1381'
					data-name='Path 1381'
					d='M15.954,19.456H5.583A2.083,2.083,0,0,1,3.5,17.373V5.583A2.083,2.083,0,0,1,5.583,3.5H15.954a2.083,2.083,0,0,1,2.083,2.083v11.79A2.084,2.084,0,0,1,15.954,19.456ZM7.667,15.29h6.2V7.667h-6.2Z'
					transform='translate(-3.5 -3.5)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2685'
				data-name='Group 2685'
				transform='translate(28.646 28.125)'
			>
				<path
					id='Path_1382'
					data-name='Path 1382'
					d='M25.729,28.083h-9.9A2.083,2.083,0,0,1,13.75,26V19.371a2.083,2.083,0,1,1,4.167,0v4.546h5.729v-6.25H21.183a2.083,2.083,0,1,1,0-4.167h4.546a2.083,2.083,0,0,1,2.083,2.083V26A2.083,2.083,0,0,1,25.729,28.083Z'
					transform='translate(-13.75 -13.5)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2686'
				data-name='Group 2686'
				transform='translate(30.019 7.292)'
			>
				<path
					id='Path_1383'
					data-name='Path 1383'
					d='M25.015,16.19H16.492a2.083,2.083,0,0,1-2.083-2.083V5.583A2.083,2.083,0,0,1,16.492,3.5h8.523A2.083,2.083,0,0,1,27.1,5.583v8.523A2.083,2.083,0,0,1,25.015,16.19Zm-6.44-4.167h4.356V7.667H18.576Z'
					transform='translate(-14.409 -3.5)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2687'
				data-name='Group 2687'
				transform='translate(7.292 9.185)'
			>
				<path
					id='Path_1384'
					data-name='Path 1384'
					d='M22.2,24.674H5.583a2.083,2.083,0,0,1,0-4.167H20.121V6.492a2.083,2.083,0,1,1,4.167,0v16.1A2.084,2.084,0,0,1,22.2,24.674Z'
					transform='translate(-3.5 -4.409)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2688'
				data-name='Group 2688'
				transform='translate(29.688 21.923)'
			>
				<path
					id='Path_1385'
					data-name='Path 1385'
					d='M16.333,17.529a2.083,2.083,0,0,1-2.083-2.083v-2.84a2.083,2.083,0,0,1,2.083-2.083h9.375a2.083,2.083,0,0,1,0,4.167H18.417v.756A2.083,2.083,0,0,1,16.333,17.529Z'
					transform='translate(-14.25 -10.523)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2689'
				data-name='Group 2689'
				transform='translate(22.963 31.102)'
			>
				<path
					id='Path_1386'
					data-name='Path 1386'
					d='M13.105,23.829a2.083,2.083,0,0,1-2.083-2.083V17.012a2.083,2.083,0,1,1,4.167,0v4.733A2.083,2.083,0,0,1,13.105,23.829Z'
					transform='translate(-11.022 -14.929)'
					fill='#526bf3'
				/>
			</g>
			<g
				id='Group_2690'
				data-name='Group 2690'
				transform='translate(7.292 30.967)'
			>
				<path
					id='Path_1387'
					data-name='Path 1387'
					d='M15.479,26.606h-9.9A2.083,2.083,0,0,1,3.5,24.522V16.947a2.083,2.083,0,0,1,2.083-2.083h9.9a2.083,2.083,0,0,1,2.083,2.083v7.575A2.083,2.083,0,0,1,15.479,26.606ZM7.667,22.439H13.4V19.031H7.667Z'
					transform='translate(-3.5 -14.864)'
					fill='#526bf3'
				/>
			</g>
		</svg>
	);
};

export default QrCodeIcon;
