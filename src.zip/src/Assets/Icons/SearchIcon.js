import React from 'react';

const SearchIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='26'
			height='26'
			viewBox='0 0 26 26'
			{...props}
		>
			<defs>
				<clipPath id='clipPath'>
					<rect width='26' height='26' fill='none' />
				</clipPath>
			</defs>
			<g id='Search' clipPath='url(#clipPath)'>
				<rect
					id='Rectangle_176'
					data-name='Rectangle 176'
					width='26'
					height='26'
					fill='none'
				/>
				<path
					id='Path_99'
					data-name='Path 99'
					d='M25.9,23.619l-5.375-5.375A11.153,11.153,0,0,0,22.805,11.4,11.332,11.332,0,0,0,11.4,0,11.332,11.332,0,0,0,0,11.4a11.332,11.332,0,0,0,11.4,11.4,11.153,11.153,0,0,0,6.842-2.281L23.619,25.9ZM3.258,11.4A8.066,8.066,0,0,1,11.4,3.258,8.066,8.066,0,0,1,19.547,11.4,8.066,8.066,0,0,1,11.4,19.547,8.066,8.066,0,0,1,3.258,11.4Z'
					fill='#526bf3'
				/>
			</g>
		</svg>
	);
};

export default SearchIcon;
