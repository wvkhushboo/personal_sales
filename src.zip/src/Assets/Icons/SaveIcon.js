import React from "react";

const SaveIcon = (props) => {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="8.361"
      height="15.256"
      viewBox="0 0 8.361 15.256"
    >
      <path
        id="Path_1249"
        data-name="Path 1249"
        d="M3751.276-20887.775h8.361v15.256l-4.071-3.926-4.107,3.926h0Z"
        transform="translate(-3751.276 20887.775)"
        fill="#fff"
      />
    </svg>
  );
};

export default SaveIcon;
