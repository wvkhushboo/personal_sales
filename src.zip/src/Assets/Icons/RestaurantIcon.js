import React from 'react';

const RestaurantIcon = (props) => {
	return (
		<svg
			id='tray'
			xmlns='http://www.w3.org/2000/svg'
			width='43.138'
			height='43.138'
			viewBox='0 0 43.138 43.138'
			{...props}
		>
			<g
				id='Group_1200'
				data-name='Group 1200'
				transform='translate(7.136 26.576)'
			>
				<g id='Group_1199' data-name='Group 1199'>
					<path
						id='Path_1052'
						data-name='Path 1052'
						d='M116.64,317.3c-.042-.07-.086-.137-.13-.2a2.806,2.806,0,0,0-3.916-.647l-8.05,5.748h-8.41a.72.72,0,1,1,0-1.44h4.68a2.523,2.523,0,0,0,2.52-2.52c0-.008,0-.074,0-.081a2.529,2.529,0,0,0-2.576-2.439H91.39a3.613,3.613,0,0,0-2.276.836l-3.521,2.931a.722.722,0,0,0-.259.554v8.64a.72.72,0,0,0,.72.72h17.865a5.052,5.052,0,0,0,3.208-1.159l8.729-7.213A2.83,2.83,0,0,0,116.64,317.3Zm-1.66,2.594-8.771,7.244a3.613,3.613,0,0,1-2.292.828H86.774v-7.583l3.262-2.716a2.166,2.166,0,0,1,1.36-.5h9.383a1.1,1.1,0,0,1,1.115,1.081,1.081,1.081,0,0,1-1.08,1.08h-4.68a2.16,2.16,0,1,0,0,4.32h8.64a.73.73,0,0,0,.42-.134l8.239-5.883a1.366,1.366,0,0,1,1.912.32c.022.03.041.06.06.091A1.4,1.4,0,0,1,114.98,319.9Z'
						transform='translate(-85.334 -315.726)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g id='Group_1202' data-name='Group 1202' transform='translate(0 29.457)'>
				<g id='Group_1201' data-name='Group 1201'>
					<path
						id='Path_1053'
						data-name='Path 1053'
						d='M7.9,349.867H0v1.44H7.179v10.8H0v1.44H7.9a.72.72,0,0,0,.72-.72V350.587A.72.72,0,0,0,7.9,349.867Z'
						transform='translate(0 -349.867)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g
				id='Group_1204'
				data-name='Group 1204'
				transform='translate(1.44 35.937)'
			>
				<g id='Group_1203' data-name='Group 1203'>
					<path
						id='Path_1054'
						data-name='Path 1054'
						d='M19.227,426.667a2.16,2.16,0,1,0,2.16,2.16A2.163,2.163,0,0,0,19.227,426.667Zm0,2.88a.72.72,0,1,1,.72-.72A.721.721,0,0,1,19.227,429.547Z'
						transform='translate(-17.067 -426.667)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g id='Group_1206' data-name='Group 1206' transform='translate(0 22.283)'>
				<g id='Group_1205' data-name='Group 1205'>
					<path
						id='Path_1055'
						data-name='Path 1055'
						d='M42.419,264.533H.719a.719.719,0,0,0-.719.72,5.042,5.042,0,0,0,5.033,5.04H38.1a5.043,5.043,0,0,0,5.033-5.04A.719.719,0,0,0,42.419,264.533Zm-4.314,4.32H5.033a3.6,3.6,0,0,1-3.522-2.88H41.627A3.6,3.6,0,0,1,38.1,268.853Z'
						transform='translate(0 -264.533)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g id='Group_1208' data-name='Group 1208' transform='translate(2.88 3.6)'>
				<g id='Group_1207' data-name='Group 1207'>
					<path
						id='Path_1056'
						data-name='Path 1056'
						d='M52.822,42.667A18.726,18.726,0,0,0,34.133,61.388v.72a.719.719,0,0,0,.719.72h35.94a.719.719,0,0,0,.719-.72v-.72A18.726,18.726,0,0,0,52.822,42.667ZM35.571,61.388a17.251,17.251,0,1,1,34.5,0Z'
						transform='translate(-34.133 -42.667)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g
				id='Group_1210'
				data-name='Group 1210'
				transform='translate(8.358 11.795)'
			>
				<g id='Group_1209' data-name='Group 1209'>
					<path
						id='Path_1057'
						data-name='Path 1057'
						d='M100.6,140.006a16.1,16.1,0,0,0-1.387,1.8l1.2.8a14.715,14.715,0,0,1,1.263-1.64Z'
						transform='translate(-99.209 -140.006)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g
				id='Group_1212'
				data-name='Group 1212'
				transform='translate(10.74 6.469)'
			>
				<g id='Group_1211' data-name='Group 1211'>
					<path
						id='Path_1058'
						data-name='Path 1058'
						d='M138.371,76.8a15.784,15.784,0,0,0-10.84,4.3l.986,1.049a14.347,14.347,0,0,1,9.854-3.909Z'
						transform='translate(-127.531 -76.8)'
						fill='#526af3'
					/>
				</g>
			</g>
			<g id='Group_1214' data-name='Group 1214' transform='translate(19.409)'>
				<g id='Group_1213' data-name='Group 1213'>
					<rect
						id='Rectangle_1586'
						data-name='Rectangle 1586'
						width='4.32'
						height='1.44'
						fill='#526af3'
					/>
				</g>
			</g>
			<g
				id='Group_1216'
				data-name='Group 1216'
				transform='translate(20.849 0.72)'
			>
				<g id='Group_1215' data-name='Group 1215'>
					<rect
						id='Rectangle_1587'
						data-name='Rectangle 1587'
						width='1.44'
						height='3.6'
						fill='#526af3'
					/>
				</g>
			</g>
		</svg>
	);
};

export default RestaurantIcon;
