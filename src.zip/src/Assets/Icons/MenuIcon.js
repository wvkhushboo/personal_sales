import React from 'react';

const MenuIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='24'
			height='22.462'
			viewBox='0 0 24 22.462'
		>
			<g id='Group_205' data-name='Group 205' transform='translate(-26 -104)'>
				<line
					id='Line_1'
					data-name='Line 1'
					x2='20'
					transform='translate(28 106)'
					fill='none'
					stroke='#fff'
					strokeLinecap='round'
					strokeWidth='4'
				/>
				<line
					id='Line_2'
					data-name='Line 2'
					x2='20'
					transform='translate(28 115.231)'
					fill='none'
					stroke='#fff'
					strokeLinecap='round'
					strokeWidth='4'
				/>
				<line
					id='Line_3'
					data-name='Line 3'
					x2='20'
					transform='translate(28 124.462)'
					fill='none'
					stroke='#fff'
					strokeLinecap='round'
					strokeWidth='4'
				/>
			</g>
		</svg>
	);
};

export default MenuIcon;
