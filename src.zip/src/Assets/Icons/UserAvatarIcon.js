import React from 'react';

const UserAvatarIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='24'
			height='24'
			viewBox='0 0 24 24'
			{...props}
		>
			<g
				id='Group_1467'
				data-name='Group 1467'
				transform='translate(-67.5 -631)'
			>
				<g id='Group_1466' data-name='Group 1466'>
					<path
						id='Path_699'
						data-name='Path 699'
						d='M12,24a12,12,0,1,1,9.176-4.266,12.126,12.126,0,0,1-1.416,1.42A12,12,0,0,1,12,24ZM12,1.5A10.5,10.5,0,0,0,3.971,18.767a10.623,10.623,0,0,0,1.24,1.243,10.5,10.5,0,0,0,13.579,0,10.623,10.623,0,0,0,1.24-1.243A10.5,10.5,0,0,0,12,1.5Z'
						transform='translate(67.5 631)'
						fill='#526af3'
					/>
				</g>
				<path
					id='Path_700'
					data-name='Path 700'
					d='M164.5,73a4.5,4.5,0,1,1,4.5-4.5A4.505,4.505,0,0,1,164.5,73Zm0-7.5a3,3,0,1,0,3,3A3,3,0,0,0,164.5,65.5Z'
					transform='translate(-85 569)'
					fill='#526af3'
				/>
				<path
					id='Path_701'
					data-name='Path 701'
					d='M95.525,234.832a.751.751,0,0,1-.728-.933,6.756,6.756,0,0,0-6.448-8.4h-.2a6.756,6.756,0,0,0-6.448,8.4.75.75,0,1,1-1.455.365A8.252,8.252,0,0,1,88.133,224h.234a8.256,8.256,0,0,1,7.885,10.264A.75.75,0,0,1,95.525,234.832Z'
					transform='translate(-8.75 416.5)'
					fill='#526af3'
				/>
			</g>
		</svg>
	);
};

export default UserAvatarIcon;
