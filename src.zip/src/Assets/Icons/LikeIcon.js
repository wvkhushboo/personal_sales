import React from 'react';

const LikeIcon = (props) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			width='18.725'
			height='16.972'
			viewBox='0 0 18.725 16.972'
			{...props}
		>
			<path
				id='Path_15'
				data-name='Path 15'
				d='M4598.181,1258.4s7.016-5.567,8.465-8.988a4.991,4.991,0,0,0-3.6-6.785c-2.319-.348-4.87,2.552-4.87,2.552s-4.292-4.407-7.713-.812,2.261,8.872,2.261,8.872Z'
				transform='translate(-4588.85 -1242.085)'
				fill='#f3526b'
				stroke='#fff'
				strokeWidth='1'
			/>
		</svg>
	);
};

export default LikeIcon;
