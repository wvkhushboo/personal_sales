import React from 'react';

const UserIcon = (props) => {
	return (
		<svg
			{...props}
			xmlns='http://www.w3.org/2000/svg'
			width='43.537'
			height='43.649'
			viewBox='0 0 43.537 43.649'
		>
			<g id='Group_1831' data-name='Group 1831' transform='translate(0 -0.313)'>
				<circle
					id='Ellipse_33'
					data-name='Ellipse 33'
					cx='11'
					cy='11'
					r='11'
					transform='translate(10.889 0.313)'
					fill='#526bf3'
				/>
				<path
					id='Path_32'
					data-name='Path 32'
					d='M21.769,10C9.8,10,0,14.9,0,20.884v5.442H43.537V20.884C43.537,14.9,33.741,10,21.769,10Z'
					transform='translate(0 17.635)'
					fill='#526bf3'
				/>
			</g>
		</svg>
	);
};

export default UserIcon;
