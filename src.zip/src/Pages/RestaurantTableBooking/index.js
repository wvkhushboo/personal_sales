import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { DatePicker, Spin } from "antd";
import { useEffect, useState } from "react";
import moment from "moment";
import { useSelector, useDispatch } from "react-redux";
import { loadStripe } from "@stripe/stripe-js";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import axios from "axios";
import {
  internalErrorNotify,
  unauthenticatedNotify,
  errorNotify,
} from "../../helpers/notiication";
import MenuPopup from "../../Components/MenuPopup";
import ConfirmBooking from "../../Components/ConfirmBooking";
// import ShareIconModule from "../../../Components/ShareIconModule/index";
import { days, dayWithStatus } from "../../helpers/DayStructure";
import SuccessPopModal from "../../Components/SuccssPopModal/index";
import Failed from "../../Components/FailedPopModal/index.js";
import FailedPopUpModal from "../../Components/failedPopUpModal";
import {
  setTableBookingResponse,
  setTableBookingValue,
} from "../../Redux/Actions/tableBookingAction";

import "./style.scss";
import MobileFooter from "../../Components/MobileFooter/index";
import { SetCancelBookingRestauarantDetails } from "../../Redux/Actions/cancelBookingData";
import Navbar from "../../Components/Navbar";
import { updateSelectedTickets } from "../../Redux/Actions/eventTicketActions";

const RestaurantTableBooking = () => {
  const [modalshow, setmodalShow] = useState(false);
  const [failedModal, setfaildModal] = useState(false);
  const [showPaymentFailedModel, setShowPaymentFailedModel] = useState(false);
  const [loader, setLoader] = useState(false);
  const [timeSlotsAndDateConfig, setTimeSlotsAndDateConfig] = useState({
    date: "",
    day: days[
      moment(
        new Date(new Date().setDate(new Date().getDate()))
          .toISOString()
          .split("T")[0]
      ).day()
    ],
    openTime: "",
    closeTime: "",
    restaurentIsOpen: true,
    disabledMinute: [],
    timeRange: [],
  });

  const [restaurantDetail, setRestaurantDetail] = useState([]);
  const [bookNowLoading, setBookNowLoading] = useState(false);
  const [bookNowDisable, setBookNowDisable] = useState(false);
  const [menuPopup, setMenuPopup] = useState(false);
  const [menuData, setMenuData] = useState([]);
  const [bookedTableData, setBookedTableData] = useState([]);
  const [dateError, setDateError] = useState("");

  const params = useParams();
  const navigate = useNavigate();

  const [showElements, setShowElements] = useState({
    calender: true,
    timeSlots: true,
    QrCode: false,
  });

  const {
    register,
    handleSubmit,
    setError,
    clearErrors,
    formState: { errors },
  } = useForm();

  const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_KEY);
  useEffect(() => {
    const tempArray = [];

    restaurantDetail?.place_time_slots &&
      restaurantDetail?.place_time_slots?.forEach((item) => {
        dayWithStatus.forEach((i) => {
          if (i.day === days[new Date().getDay()]) {
            if (i.statusCode === item.week_day) {
              tempArray.push({
                opentime: item.open_time,
                closeTime: item.close_time,
                restaurentIsOpen: item.week_day_status,
              });
            }
          }
        });
      });
  }, [restaurantDetail]);

  const [placeAreaTimeSlots, setPlaceAreaTimeSlots] = useState({
    placeAreaDetail: undefined,
    date: "",
    showTimeInput: false,
    timeSlotArray: [],
  });

  useEffect(() => {
    const createSlots = [];
    if (
      placeAreaTimeSlots.placeAreaDetail !== undefined &&
      placeAreaTimeSlots.date !== ""
    ) {
      if (
        placeAreaTimeSlots?.placeAreaDetail?.place_area_time_slots.length === 0
      ) {
        setPlaceAreaTimeSlots({
          ...placeAreaTimeSlots,
          showTimeInput: false,
        });
        setError("date", {
          type: "manual",
          message: "* Restaurant is closed",
        });
      } else {
        clearErrors("area");

        if (placeAreaTimeSlots?.date) {
          setPlaceAreaTimeSlots({
            ...placeAreaTimeSlots,
            timeSlotArray: [],
          });
          const day =
            days[
              moment(
                new Date(placeAreaTimeSlots?.date).toISOString().split("T")[0]
              ).day()
            ];

          dayWithStatus?.forEach((dayWithStatus) => {
            if (dayWithStatus?.day === day) {
              if (
                JSON.parse(
                  placeAreaTimeSlots?.placeAreaDetail?.week_day_status
                )[dayWithStatus?.statusCode] === 1
              ) {
                clearErrors("date");
                setBookNowDisable(false);
                placeAreaTimeSlots?.placeAreaDetail?.place_area_time_slots?.forEach(
                  (item) => {
                    if (item?.week_day === dayWithStatus?.statusCode) {
                      createSlots.push(
                        ...createSlots,
                        calculateTimeSlot(
                          parseTime(item?.open_time),
                          parseTime(item?.close_time)
                        )
                      );
                    }
                  }
                );

                setPlaceAreaTimeSlots({
                  ...placeAreaTimeSlots,
                  timeSlotArray: createSlots.flat(),
                  showTimeInput: true,
                });
                setBookNowDisable(false);
              } else {
                setPlaceAreaTimeSlots({
                  ...placeAreaTimeSlots,
                  showTimeInput: false,
                });

                setBookNowDisable(true);
                setError("date", {
                  type: "manual",
                  message: "* Restaurant is closed",
                });
              }
            }
          });
        }
      }
    } else {
      if (
        placeAreaTimeSlots.placeAreaDetail === undefined &&
        placeAreaTimeSlots.date
      ) {
        setError("area", {
          type: "manual",
          message: "* Please choose place area first",
        });
      } else {
        clearErrors("area");
      }
    }
    //eslint-disable-next-line
  }, [placeAreaTimeSlots?.date, placeAreaTimeSlots?.placeAreaDetail]);

  const dispatch = useDispatch();

  const { formValue } = useSelector((state) => state.tableBookingReducer);
  const { responseData } = useSelector(
    (state) => state.tablebookingresponsedatareducer
  );

  useEffect(() => {
    const tempSlotsArray = [];
    const tempOpenTime = [];
    const tempCloseTime = [];

    timeSlotsAndDateConfig.day &&
      dayWithStatus.forEach((dayWithStatus) => {
        if (dayWithStatus.day === timeSlotsAndDateConfig.day) {
          if (restaurantDetail?.place_time_slots) {
            restaurantDetail?.place_time_slots.forEach((timeSlots) => {
              if (timeSlots.week_day === dayWithStatus.statusCode) {
                tempSlotsArray.push(timeSlots);
              }
            });
          }
        }
      });
    tempSlotsArray.forEach((slots) => {
      tempCloseTime.push(slots?.close_time);
      tempOpenTime.push(slots?.open_time);
      setTimeSlotsAndDateConfig({
        ...timeSlotsAndDateConfig,
        openTime: [...tempOpenTime],
        closeTime: [...tempCloseTime],
        restaurentIsOpen: slots?.week_day_status === 1 ? true : false,
      });
    });
    //eslint-disable-next-line
  }, [timeSlotsAndDateConfig?.day, restaurantDetail]);

  // making time slots from open and close time
  function parseTime(s) {
    var c = s.split(":");
    return parseInt(c[0]) * 60 + parseInt(c[1]);
  }
  function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
  }
  function convertHours(mins) {
    var hour = Math.floor(mins / 60);
    mins = mins % 60;
    var converted = pad(hour, 2) + ":" + pad(mins, 2);
    return converted;
  }

  function calculateTimeSlot(start_time, end_time) {
    //
    const interval = 30;
    var formatted_time;
    var time_slots = [];
    for (var i = start_time; i < end_time; i = i + interval) {
      formatted_time = convertHours(i);
      time_slots.push(formatted_time);
    }
    return time_slots;
  }

  const onSubmit = (data) => {
    // storing value in local storage - payment failed modal should be visible when  user goes back from browser instead of stripe payment gateway's back
    if (placeAreaTimeSlots?.date === "" || !placeAreaTimeSlots?.date) {
      setDateError("Please select booking date");
      return;
    }
    if (restaurantDetail?.booking_fee >= 1) {
      handleclick(data);
    } else {
      handleclick(data);
    }
    setShowElements({
      ...showElements,
      calender: true,
    });
    setBookedTableData(data);

    // adding form values to the store
    const { name, email, mobileNumber, guestCount, date, area } = data;
    dispatch(
      setTableBookingValue({
        ...formValue,
        name: name,
        emailAddress: email,
        mobileNumber: mobileNumber,
        guestCount: guestCount,
        date: date,
        // time: restaurantTableBookingTime,
        time: "",
        placeAreaName: area,
      })
    );
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    axios
      .get(
        `${process.env.REACT_APP_API_URL}/get-restaurant-details/${params.id}`
      )
      .then((res) => {
        if (res.data.status === "200") {
          setRestaurantDetail(res.data.data.restaurants);
          // history("/restaurant-table-booking/:id",{state:restaurantDetail});
        } else if (res.data.status === "201") {
          errorNotify(res.data.message);
        } else {
          internalErrorNotify();
        }
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(navigate);
        } else {
          internalErrorNotify();
        }
      });
    //eslint-disable-next-line
  }, []);

  useEffect(() => {
    var url = window.location.href;
    var query = new URL(url);
    var success = query.searchParams.get("success");
    var session_id = query.searchParams.get("session_id");
    var cancelled = query.searchParams.get("cancel");
    if (success === "true") {
      localStorage.setItem("initiatingPayment", false);
      setShowPaymentFailedModel(false);
      // retrieveStripeSession(session_id);
      setLoader(true);
    } else if (cancelled && cancelled === "true") {
      setShowPaymentFailedModel(true);
      localStorage.removeItem("initiatingPayment");
    } else if (localStorage.getItem("initiatingPayment")) {
      setShowPaymentFailedModel(true);
      localStorage.removeItem("initiatingPayment");
    }
    //eslint-disable-next-line
  }, []);

  const retrieveStripeSession = (session_id) => {
    let config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("hhr_token")}`,
      },
    };
    const formdata = new FormData();

    formdata.append("stripe_session_id", session_id);

    formdata.append("booking_id", responseData[0]?.id);
    formdata.append("payment_mode", "1");
    formdata.append("booking_type", "1");

    axios
      .post(
        `${process.env.REACT_APP_API_URL}/retrive-stripe-session`,
        formdata,
        config
      )
      .then((res) => {
        if (res?.data?.status === "200") {
          setShowElements({
            QrCode: true,
          });

          setmodalShow(true);
          setLoader(false);

          window.history.pushState({}, "", `${window.location.pathname}`);
        } else if (res?.data?.status === "201") {
          setShowElements({
            QrCode: false,
          });
          setfaildModal(true);
          setLoader(false);
        } else {
          internalErrorNotify();
        }
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(navigate);
        } else {
          internalErrorNotify();
        }
      });
  };

  const handleclick = (data) => {
    let config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("hhr_token")}`,
      },
    };

    const formdata = new FormData();
    formdata.append(
      "venue_admin_id",
      restaurantDetail && restaurantDetail?.user_id
    );
    formdata.append("restaurant_id", restaurantDetail && restaurantDetail?.id);
    formdata.append("place_area_id", JSON.parse(data?.area)?.place_area_id);
    formdata.append("customer_name", data?.name);
    formdata.append("customer_email", data?.email);
    formdata.append("customer_mobile_number", data?.mobileNumber);
    formdata.append("date", moment(placeAreaTimeSlots?.date).unix());
    formdata.append("time", data?.time.toString());

    formdata.append("guest_count", data?.guestCount);
    formdata.append("booking_amount", restaurantDetail?.booking_fee);
    formdata.append(
      "return_url",
      `${window.location.origin}${window.location.pathname}`
    );
    setBookNowLoading(true);
    axios
      .post(`${process.env.REACT_APP_API_URL}/table-booking`, formdata, config)
      .then((res) => {
        if (res?.data?.status === "200") {
          dispatch(setTableBookingResponse(res?.data?.data));
          setShowElements({
            QrCode: true,
          });

          setmodalShow(true);
          setLoader(false);
          setBookNowLoading(false);
          setTableBookingResponse(res?.data?.data);

          window.history.pushState({}, "", `${window.location.pathname}`);
          // if (restaurantDetail?.booking_fee > 0) {
          //   localStorage.setItem("initiatingPayment", true);
          //   // HandleStripe(res?.data?.data.map((item) => item));

          //   setShowElements({
          //     QrCode: false,
          //   });
          // } else {
          //   setShowElements({
          //     QrCode: true,
          //   });
          //   setBookNowLoading(false);
          //   setTableBookingResponse(res?.data?.data);

          // }
        } else if (res?.data?.status === "201") {
          errorNotify(res?.data?.message);
          setBookNowLoading(false);
        } else {
          internalErrorNotify();
          setBookNowLoading(false);
        }
        setBookNowLoading(false);
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(navigate);
        } else {
          internalErrorNotify();
        }

        setBookNowLoading(false);
      });
  };

  const HandleStripe = async (stripeCheckoutSessionId) => {
    const sessionId = await stripeCheckoutSessionId.map(
      (i) => i?.stripe_checkout_session_id
    );
    if (sessionId) {
      const stripe = await stripePromise;
      const result = await stripe.redirectToCheckout({
        sessionId: sessionId[0],
      });
      if (result.error) {
      }
    }
  };

  // Validate guests number on onChange
  const handleGuestsNumber = (guestsCount) => {
    guestsCount.match(/^[1-9][0-9]*$/) || guestsCount === ""
      ? clearErrors("guestCount")
      : setError("guestCount", {
          type: "manual",
          message: "Guest number can't be negative or zero",
        });
  };

  // Validate email address on onChange
  const handleEmailChange = (emailAddress) => {
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+[.]+[.a-zA-Z]{2,8}$/;
    emailAddress.match(emailRegex) || emailAddress === ""
      ? clearErrors("email")
      : setError("email", {
          type: "manual",
          message: "Please enter a valid e-mail address",
        });
  };

  let upcomingTime = [];

  const isRestaurantOpen = (current) => {
    // disable date on recent dates and if the restaurant is closed for selected area
    const days_status = JSON.parse(
      placeAreaTimeSlots?.placeAreaDetail?.week_day_status
    );
    const days = {
      Mon: days_status[0],
      Tue: days_status[1],
      Wed: days_status[2],
      Thu: days_status[3],
      Fri: days_status[4],
      Sat: days_status[5],
      Sun: days_status[6],
    };
    let customDate = moment().format("YYYY-MM-DD");
    if (
      current < moment(customDate, "YYYY-MM-DD") ||
      days[moment(current).format("ddd")] === 0
    ) {
      return true;
    } else {
      return false;
    }
    // }
    // catch {
    //   () => {
    //     setError("area", {
    //       type: "manual",
    //       message: "* Please choose place area first",
    //     });
    //   };
    // }
  };

  return (
    <>
      <Navbar
        title={"Table Booking"}
        leftIcon={<ArrowLeftIcon to={"/sell-table-booking"} />}
      />
      <div className="restaurantTableBookingComponent">
        <Spin size="large" spinning={loader}>
          <div className="bookingdiv">
            {modalshow && <SuccessPopModal />}
            {failedModal && <Failed />}
            <div className="restorentSingle pb-80">
              <div
                className="container singleResContainer"
                style={{ paddingTop: "50px" }}
              >
                <div className="row justify-content-center">
                  <div className="col-md-6 " id="TableBooking">
                    <h2
                      className="heading_2 "
                      style={{
                        display: showElements?.QrCode ? "none" : "block",
                        textAlign: "center",
                      }}
                    >
                      Table Booking
                    </h2>
                    <div className="mb-30">
                      {parseInt(restaurantDetail?.status) === 1 ||
                      !restaurantDetail?.status ? (
                        <>
                          <form
                            onSubmit={handleSubmit(onSubmit)}
                            style={{
                              display: showElements?.QrCode ? "none" : "block",
                            }}
                          >
                            <div className="row">
                              <div className="col-md-6">
                                <div className="form-group">
                                  <p className="formLabel">Place area</p>

                                  <select
                                    style={{
                                      maxWidth: "100%",
                                      borderRadius: "20px",
                                    }}
                                    className="form-control"
                                    {...register("area", {
                                      required: "* Place area is required",
                                    })}
                                    onChange={(e) => {
                                      setPlaceAreaTimeSlots({
                                        ...placeAreaTimeSlots,
                                        placeAreaDetail: JSON.parse(
                                          e.target.value
                                        ),
                                      });
                                    }}
                                  >
                                    {restaurantDetail?.place_areas?.length >
                                    0 ? (
                                      <>
                                        <option
                                          value=""
                                          selected
                                          disabled
                                          hidden
                                        >
                                          Select place
                                        </option>
                                        {restaurantDetail?.place_areas?.map(
                                          (item, index) => (
                                            <option
                                              value={JSON.stringify(item)}
                                              key={index}
                                            >
                                              {item?.area_name}
                                            </option>
                                          )
                                        )}
                                      </>
                                    ) : (
                                      <>
                                        <option
                                          value=""
                                          selected
                                          disabled
                                          hidden
                                        >
                                          Select place
                                        </option>
                                        <option value="" disabled>
                                          No place area
                                        </option>
                                      </>
                                    )}
                                  </select>
                                  {errors.area && (
                                    <span className="input-error">
                                      {errors.area.message}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="form-group">
                                  <p className="formLabel">Guests</p>
                                  <input
                                    className="form-control"
                                    type="number"
                                    placeholder="Enter guest count"
                                    {...register("guestCount", {
                                      required: "* Guest count is required",
                                      pattern: {
                                        value: /^[1-9][0-9]*$/, //  /^\d+$/
                                        message:
                                          "Guest number can't be negative or zero",
                                      },
                                      onChange: (e) => {
                                        handleGuestsNumber(e.target.value);
                                      },
                                    })}
                                  />
                                  {errors.guestCount && (
                                    <span className="input-error">
                                      {errors.guestCount.message}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-6">
                                <div className="form-group">
                                  <p className="formLabel">Mobile number</p>
                                  <input
                                    className="form-control mobile-number"
                                    autoComplete="off"
                                    type="number"
                                    // type="tel"
                                    placeholder="Enter mobile number"
                                    maxLength={10}
                                    {...register("mobileNumber", {
                                      required: "* Mobile number is required",
                                      minLength: {
                                        value: 10,
                                        message:
                                          "Please enter a 10 digit mobile number",
                                      },
                                      maxLength: {
                                        value: 10,
                                        message:
                                          "Please enter a 10 digit mobile number",
                                      },
                                      pattern: {
                                        value: /^[0-9]+$/,
                                        message:
                                          "Please enter a valid 10 digit mobile number",
                                      },
                                    })}
                                  />
                                  {errors.mobileNumber && (
                                    <span className="input-error">
                                      {errors.mobileNumber.message}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="form-group">
                                  <p className="formLabel">Name</p>
                                  <input
                                    className="form-control"
                                    type="text"
                                    placeholder="Enter name"
                                    {...register("name", {
                                      required: "* Name is required",
                                      pattern: {
                                        value: /^[A-Za-z ]+$/,
                                        message: "Enter a valid name",
                                      },
                                    })}
                                  />
                                  {errors.name && (
                                    <span className="input-error">
                                      {errors.name.message}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-md-6">
                                <div className="form-group">
                                  <p className="formLabel">E-mail address</p>
                                  <input
                                    className="form-control"
                                    type="text"
                                    placeholder="Enter e-mail id"
                                    {...register("email", {
                                      required: "* Email is required",
                                      onChange: (e) => {
                                        handleEmailChange(e.target.value);
                                      },
                                      pattern: {
                                        value: RegExp(
                                          "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$"
                                        ),
                                        message:
                                          "Please enter a valid e-mail address",
                                      },
                                    })}
                                  />
                                  {errors.email && (
                                    <span className="input-error">
                                      {errors.email.message}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="form-group">
                                  <p className="formLabel">Select date</p>
                                  <DatePicker
                                    disabledDate={(current) =>
                                      placeAreaTimeSlots?.placeAreaDetail &&
                                      isRestaurantOpen(current)
                                    }
                                    onClick={() =>
                                      !placeAreaTimeSlots?.placeAreaDetail &&
                                      setError("area", {
                                        type: "manual",
                                        message:
                                          "* Please choose place area first",
                                      })
                                    }
                                    inputReadOnly
                                    onSelect={(date) => {
                                      setDateError("");
                                      setPlaceAreaTimeSlots({
                                        ...placeAreaTimeSlots,
                                        date: moment(date).format("YYYY-MM-DD"),
                                      });
                                    }}
                                  />
                                  {errors.date && (
                                    <span className="input-error">
                                      {errors?.date?.message}
                                    </span>
                                  )}
                                  {dateError && (
                                    <span className="input-error">
                                      {dateError}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-6">
                                {placeAreaTimeSlots?.showTimeInput && (
                                  <div className="form-group">
                                    <p className="formLabel">Select time</p>

                                    <select
                                      style={{ maxWidth: "100%" }}
                                      className="form-control"
                                      {...register("time", {
                                        required: "* Please select a time slot",
                                      })}
                                    >
                                      {placeAreaTimeSlots?.timeSlotArray
                                        ?.length > 0 ? (
                                        <>
                                          <option
                                            value=""
                                            selected
                                            disabled
                                            hidden
                                          >
                                            Select time
                                          </option>
                                          {
                                            (upcomingTime =
                                              placeAreaTimeSlots?.timeSlotArray?.filter(
                                                (item) =>
                                                  item >
                                                  moment().format("HH:mm")
                                              ))
                                          }
                                          {moment(
                                            placeAreaTimeSlots.date
                                          ).isSame(Date.now(), "day") ? (
                                            upcomingTime.length ? (
                                              upcomingTime?.map(
                                                (data, index) => (
                                                  <option
                                                    value={data}
                                                    key={index}
                                                  >
                                                    {" "}
                                                    {data}
                                                  </option>
                                                )
                                              )
                                            ) : (
                                              <option disabled>
                                                No Time Slots Available
                                              </option>
                                            )
                                          ) : (
                                            placeAreaTimeSlots?.timeSlotArray?.map(
                                              (data, index) => (
                                                <option
                                                  value={data}
                                                  key={index}
                                                >
                                                  {" "}
                                                  {data}
                                                </option>
                                              )
                                            )
                                          )}
                                        </>
                                      ) : (
                                        <>
                                          <option
                                            value=""
                                            selected
                                            disabled
                                            hidden
                                          >
                                            Select time
                                          </option>
                                          <option value="" disabled>
                                            No time slots
                                          </option>
                                        </>
                                      )}
                                    </select>

                                    {errors.time && (
                                      <span className="input-error">
                                        {errors.time.message}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="white-green-btn mt-10">
                              {bookNowLoading ? (
                                <button
                                  className="btn btn-wg-green"
                                  type="submit"
                                  disabled={bookNowDisable}
                                >
                                  <span
                                    className="spinner-border spinner-border-sm mr-2"
                                    role="status"
                                    aria-hidden="true"
                                  ></span>
                                  Book Now
                                </button>
                              ) : (
                                <button
                                  className="btn btn-wg-green"
                                  type="submit"
                                  disabled={bookNowDisable}
                                >
                                  Book Now
                                </button>
                              )}
                              <button
                                className="btn btn-wg-white"
                                type="button"
                                onClick={() => {
                                  navigate("/cancel-reservation");
                                  dispatch(
                                    SetCancelBookingRestauarantDetails(
                                      restaurantDetail
                                    )
                                  );
                                }}
                              >
                                Manage Booking
                              </button>
                            </div>
                          </form>
                        </>
                      ) : (
                        restaurantDetail?.status === 0 && (
                          <p>No Bookings Available</p>
                        )
                      )}
                      <div id="ConfirmBooking">
                        {showElements?.QrCode && (
                          <ConfirmBooking
                            restaurantName={restaurantDetail?.restaurant_name}
                            bookedTableData={bookedTableData}
                            maindata={responseData}
                            bookingFees={`€ ${restaurantDetail?.booking_fee}`}
                          />
                        )}
                        {showElements?.QrCode && (
                          <div className="text-center w-50 m-auto ">
                            <button
                              className="bookanotherBtn fw-bold noprint mt-3"
                              onClick={() => {
                                setShowElements({
                                  calender: true,
                                  timeSlots: true,
                                  QrCode: false,
                                });
                              }}
                            >
                              Book another table
                            </button>

                            <button
                              className="bookanotherBtn fw-bold noprint mt-3"
                              onClick={() => navigate("/sell-table-booking")}
                            >
                              Go Back
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {menuPopup && (
                    <MenuPopup
                      menuData={menuData}
                      setMenuPopup={setMenuPopup}
                      setMenuData={setMenuData}
                      restaurant_id={params.id}
                    />
                  )}
                  {showPaymentFailedModel && (
                    <FailedPopUpModal message={"table-booking"} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </Spin>
      </div>
      <MobileFooter />
    </>
  );
};

export default RestaurantTableBooking;
