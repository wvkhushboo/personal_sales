import React, { useEffect } from "react";
import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import { Link, useNavigate } from "react-router-dom";

import LogoutIcon from "../../Assets/Icons/LogoutIcon";
import RightSignIcon from "../../Assets/Icons/RightSignIcon";
import TicketIcon from "../../Assets/Icons/TicketIcon";
import TicketWalletIcon from "../../Assets/Icons/TicketWalletIcon";
import AccountIcon from "../../Assets/Icons/AccountIcon";
import TableBookingIcon from "../../Assets/Icons/TableBookingIcon";
import BellMenuIcon from "../../Assets/Icons/BellMenuIcon";
import OfferIcon from "../../Assets/Icons/OfferIcon";

import "./index.css";
import { useDispatch } from "react-redux";
import { Button, Modal } from "react-bootstrap";
import { logout } from "../../Redux/Actions/signInActions";
import axios from "axios";
import { useState } from "react";

const Account = () => {
  const [modalShow, setModalShow] = React.useState(false);
  const [companyName, setCompanyName] = useState("");

  const navigate = useNavigate();

  const dispatch = useDispatch();

  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  const signout = () => {
    localStorage.setItem("Login", JSON.stringify({ isAuth: false, token: "" }));
    dispatch(logout());
    navigate("/");
  };

  const fetchCompanyName = async () => {
    const { data: response } = await axios.get(
      `${process.env.REACT_APP_API_URL}/salesman/profile`,
      {
        headers: {
          Authorization: `Bearer ${logData.token}`,
        },
      }
    );
    setCompanyName(response.data.company_name);
  };

  useEffect(() => {
    fetchCompanyName();

    // eslint-disable-next-line
  }, []);

  return (
    <>
      <Navbar title="Profile" leftIcon={<ArrowLeftIcon />} />
      <div className="container myAccountContainer">
        <div className="text-center mt-3">
          <h4 className="font-weight-bold">{companyName}</h4>{" "}
          {/* Will be dynamic later */}
          <h4 className="font-weight-bold">Sales Team</h4>
        </div>
        <div className="col-lg-12 mt-4 menuContainer">
          <ul className="ac_menu">
            <Link to="/sell-tickets">
              <li className="border-bottom">
                <span className="leftIcon">
                  <TicketIcon />
                </span>
                <span>Sell Tickets</span>
                <span className="rightIcon">
                  <RightSignIcon />
                </span>
              </li>
            </Link>
            <Link to="/sell-table-booking">
              <li className="border-bottom">
                <span className="leftIcon">
                  <TableBookingIcon />
                </span>
                <span>Sell Table Booking</span>
                <span className="rightIcon">
                  <RightSignIcon />
                </span>
              </li>
            </Link>
            <Link to="/sell-menu">
              <li className="border-bottom">
                <span className="leftIcon">
                  <BellMenuIcon />
                </span>
                <span>Sell Menu</span>
                <span className="rightIcon">
                  <RightSignIcon />
                </span>
              </li>
            </Link>
            <Link to="/send-offer">
              <li className="border-bottom">
                <span className="leftIcon">
                  <OfferIcon />
                </span>
                <span>Send Offer</span>
                <span className="rightIcon">
                  <RightSignIcon />
                </span>
              </li>
            </Link>
            <Link to="/my-commission">
              <li className="border-bottom">
                <span className="leftIcon">
                  <TicketWalletIcon />
                </span>
                <span>My Sold Tickets</span>
                <span className="rightIcon">
                  <RightSignIcon />
                </span>
              </li>
            </Link>
            <Link to="/my-account">
              <li className="border-bottom">
                <span className="leftIcon">
                  <AccountIcon />
                </span>
                <span>My Account</span>
                <span className="rightIcon">
                  <RightSignIcon />
                </span>
              </li>
            </Link>
            {/* <Link to="/"> */}
            <li
              onClick={() => setModalShow(true)}
              style={{ cursor: "pointer" }}
            >
              <span className="leftIcon">
                <LogoutIcon />
              </span>
              <span>Logout</span>
              <span className="rightIcon">
                <RightSignIcon />
              </span>
            </li>
            {/* </Link> */}
          </ul>
        </div>
      </div>
      <Modal
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={modalShow}
      >
        <Modal.Body className="text-center">
          <LogoutIcon />
          <h5 className="mt-2">Are you sure?</h5>
          <h5>You want to Logout</h5>
          <div className="mt-3 modalBtn">
            <Button
              onClick={() => {
                setModalShow(false);
                signout();
              }}
              className="me-2"
            >
              Logout
            </Button>
            <Button onClick={() => setModalShow(false)}>Close</Button>
          </div>
        </Modal.Body>
      </Modal>

      <MobileFooter />
    </>
  );
};

export default Account;
