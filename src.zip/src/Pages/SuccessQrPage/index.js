import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router";
import ShareIcon from "../../Assets/Icons/ShareIcon";
import ShareIconModule from "../../Components/ShareIconModule";
import {
  errorNotify,
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication";
import axios from "axios";
import FailedPopUpModal from "../../Components/failedPopUpModal";
import "./style.scss";
import { DownloadOutlined } from "@ant-design/icons";
import * as moment from "moment";
import { Spin, Table } from "antd";
import { updateSelectedTickets } from "../../Redux/Actions/eventTicketActions";

export default function SuccessQrPage(props) {
  const [shareShow, setShareShow] = useState(false);
  const [ticketDetail, setTicketDetail] = useState({ id: "", qrImage: "" });
  const [loader, setLoader] = useState(false);

  const search = useLocation().search;
  const cancel_stripe = new URLSearchParams(search).get("cancel");
  const success_stripe = new URLSearchParams(search).get("success");
  const maindata = useSelector(
    (state) => state.tablebookingresponsedatareducer.tablebookingresponsedata
  );
  // getting email id of authenticated user
  // const userLoginData = useSelector((state) => state.authLoginReducer.authUser);

  // getting details of the event
  const { data: eventData } = useSelector(
    (state) => state.getSingleEventReducer
  );
  const ticketquantity = useSelector(
    (state) => state.eventticketquantityreducer.eventticketquantity
  );

  // table for ticket
  const columns = [
    {
      title: "Person type",
      dataIndex: "person",
    },
    {
      title: "No. of tickets",
      dataIndex: "tickets",
    },
    {
      title: "Price",
      dataIndex: "price",
    },
  ];

  const rows = [];
  let totalTickets = 0;
  let totalPrice = 0;
  ticketquantity?.map((item) => {
    rows.push({
      person: item?.person_type,
      tickets: item?.intital_quantity,
      price: item?.amount
        ? `€ ${item?.amount?.toFixed(2)}`
        : `€ ${item?.sales_price?.toFixed(2)}`,
    });
    totalTickets += item?.intital_quantity;
    totalPrice += item?.amount ? item?.amount : item?.sales_price;

    return rows;
  });

  const total = <p style={{ fontWeight: "bold", marginBottom: "0" }}>Total</p>;
  rows.push({
    person: total,
    tickets: (
      <p style={{ fontWeight: "bold", marginBottom: "0" }}>{totalTickets}</p>
    ),
    price: (
      <p style={{ fontWeight: "bold", marginBottom: "0" }}>
        € {totalPrice.toFixed(2)}
      </p>
    ),
  });
  const navigate = useNavigate();
  const nextPage = () => {
    navigate("/sell-tickets");
  };
  const [data, setData] = useState();
  const dispatch = useDispatch();
  useEffect(() => {
    var url = window.location.href;
    var query = new URL(url);
    var canceled = query.searchParams.get("cancel");
    var success = query.searchParams.get("success");

    if (success === "true") {
      dispatch(updateSelectedTickets({}));
      // retrieveStripeSession();
      setLoader(true);
    } else if (canceled && canceled === "true") {
      dispatch(updateSelectedTickets({}));
      <FailedPopUpModal />;
    }

    // eslint-disable-next-line
  }, []);

  const retrieveStripeSession = () => {
    const session = maindata?.map((i) => i?.stripe_checkout_session_id);

    var sessionDataId = session?.[0];

    const booking = maindata?.map((i) => i?.id);
    var bookingId = booking?.[0];

    console.log(bookingId);

    const formdata = new FormData();
    formdata.append("stripe_session_id", sessionDataId);
    formdata.append("booking_id", bookingId);
    formdata.append("payment_mode", 1);
    formdata.append("booking_type", 1);

    axios
      .post(`${process.env.REACT_APP_API_URL}/retrive-stripe-session`, formdata)
      .then((res) => {
        if (res.data.status === "200") {
          console.log(res.data);
          setData(res.data);
          setLoader(false);
        } else if (res.data.status === "201") {
          setLoader(false);
          errorNotify(res.data.message);
        } else {
          internalErrorNotify();
        }
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(props.history);
        } else {
          internalErrorNotify();
        }
      });
  };

  useEffect(() => {
    const handleClickdetail = () => {
      setTicketDetail({
        id: maindata[0]?.number_id,
        qrImage: maindata[0]?.booking_qr_code,
      });
    };
    handleClickdetail();
    // eslint-disable-next-line
  }, []);

  // event table
  return (
    <div className="successQrPageComponent">
      <Spin size="large" spinning={loader} style={{ height: "100vh" }}>
        <div className="d-flex justify-content-center">
          {
            <div
              className="successQrPageComponent container"
              id="printableArea"
              style={{ paddingTop: "50px" }}
            >
              <div id="mydiv">
                <h3 className="heading_3 text-center mt-4">
                  Booking Confirmed
                </h3>

                <div className="bookingConfirmTickets mb-30">
                  <div className="d-flex justify-content-end noprint">
                    <DownloadOutlined
                      className="downloadBtn "
                      onClick={() => window.print()}
                    />{" "}
                    <ShareIcon
                      style={{
                        cursor: "pointer",
                        marginLeft: "10px",
                        color: "#536BF3",
                        marginTop: "1px",
                      }}
                      onClick={() => setShareShow(true)}
                    ></ShareIcon>
                    <ShareIconModule
                      shareShow={shareShow}
                      setShareShow={setShareShow}
                      ticketDetail={ticketDetail}
                    />
                  </div>
                  <div className="row" style={{ justifyContent: "center" }}>
                    {maindata?.map((i, index) => (
                      <div className="col-md-6 print-col-6" key={index}>
                        <div className="checkoutBookingConfirmation">
                          <div className="text-center">
                            <img
                              src={`${process.env.REACT_APP_API_URL.slice(
                                0,
                                -3
                              )}${i?.booking_qr_code}`}
                              alt="qr-code"
                              className="qrCodeImg "
                              style={{ width: "69%" }}
                            />
                          </div>
                          <div className="text-center mb-15">
                            <h4 className="heading_5">
                              Booking ID {i?.child_id}
                            </h4>
                            <p className="mb-1 mt-1">
                              <b>Booking Slot - </b>
                              {moment(eventData?.event_start_date).format(
                                "DD MMM"
                              )}{" "}
                              -{" "}
                              {moment(eventData?.event_end_date).format(
                                "DD MMM"
                              )}{" "}
                              at {eventData?.event_start_time} -{" "}
                              {eventData?.event_end_time}
                            </p>
                            <h6
                              className="mb-10 mt-3"
                              style={{ fontWeight: 600 }}
                            >
                              Booking Confirmed For {totalTickets}{" "}
                              {parseInt(totalTickets) === 1
                                ? "Guest"
                                : "Guests"}
                            </h6>
                            Company VAT / TAX ID number -
                            <span
                              className="mb-10 mt-3"
                              style={{ fontWeight: 600 }}
                            >
                              {" "}
                              {eventData?.vat_id}
                            </span>
                          </div>
                          <Table
                            columns={columns}
                            dataSource={rows}
                            pagination={false}
                            size={"small"}
                          />
                          <div className="text-end vatDiv">
                            Includes {eventData?.vat_percentage || 0}% VAT €{" "}
                            {(
                              (totalPrice * eventData?.vat_percentage) /
                              100
                            ).toFixed(2) || 0}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="col-12 mt-5">
                    <div
                      className="booking__confirm__seller d-flex"
                      style={{ padding: "0 15px" }}
                    >
                      <div className="col-8 ">
                        <p className="fw-bold">SELLER</p>
                        <p className="date" style={{ marginTop: "-10px" }}>
                          {eventData?.event_place?.[0].restaurant_name}
                        </p>
                      </div>
                      <div
                        className="col-4 "
                        style={{
                          display: "grid",
                          placeItems: "end",
                          marginRight: "10px",
                        }}
                      >
                        <p className="fw-bold">BOOKING DATE</p>
                        <p className="date" style={{ marginTop: "-10px" }}>
                          {moment().format("DD MMM YYYY, HH:mm")}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div
                    className="mt-20 pb-20 mb-4"
                    style={{ display: "flex", justifyContent: "center" }}
                  >
                    <button
                      className="btn btn-primary maxButton col-6 me-2 "
                      onClick={() => nextPage()}
                    >
                      OK
                    </button>
                    <button
                      className="btn btn-primary maxButton col-6"
                      onClick={() => nextPage()}
                    >
                      Go Back
                    </button>
                  </div>
                </div>
              </div>
            </div>
          }
          {cancel_stripe && (
            <div className="customeHeader">
              <FailedPopUpModal />
            </div>
          )}
        </div>
      </Spin>
    </div>
  );
}
