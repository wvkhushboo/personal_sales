import React from "react";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import Navbar from "../../Components/Navbar";
import errorImg from "../../Assets/Images/errorImage.png";
import "./index.css";

const PageNotFound = () => {
  return (
    <>
      <Navbar title={"Page Not Found"} leftIcon={<ArrowLeftIcon />} />
      <div className="container">
        <div className="row">
          <div className="col">
            <img src={errorImg} alt="errorImg" className="error-img" />
          </div>
        </div>
      </div>
      <MobileFooter />
    </>
  );
};

export default PageNotFound;
