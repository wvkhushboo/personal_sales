import React from "react";
import "./index.css";
// import { useForm } from "react-hook-form";
// import Logo from "../../Assets/images/logo-black.png";

// import { Button } from "antd-mobile";
// import { useNavigate } from "react-router-dom";
// import { useDispatch } from "react-redux";
// import { setEmail } from "../../Redux/Actions/signInActions";
import Navbar from "../../Components/Navbar";
import MenuIcon from "../../Assets/Icons/MenuIcon";
import MobileFooter from "../../Components/MobileFooter";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const Home = () => {
  const navigate = useNavigate();

  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  // const {
  //   register,
  //   handleSubmit,
  //   formState: { errors },
  // } = useForm({
  //   mode: "onSubmit",
  // });

  // const navigate = useNavigate();
  // const dispatch = useDispatch();

  // const onSubmit = (data) => {
  //   dispatch(setEmail(data.email));

  //   navigate("/password");

  //   document.querySelector("#userEmail").value = "";
  // };

  return (
    <>
      <Navbar title="Home" leftIcon={<MenuIcon />} />
      <div className="container"></div>
      <MobileFooter />
    </>
  );
};

export default Home;
