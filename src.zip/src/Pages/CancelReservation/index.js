import { Link, useNavigate } from "react-router-dom";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import ReservedImage from "../../Assets/Images/reserved.jpg";
import axios from "axios";
import { cancelBookingData } from "../../Redux/Actions/cancelBookingData";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { message, Spin } from "antd";
import "./style.scss";
import Navbar from "../../Components/Navbar";

const CancelReservation = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [formData, updateFormData] = useState({
    booking_id: "",
    mobile_num: "",
    loading: false,
  });

  const onChange = (e) => {
    updateFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const { cancelBookingRestaurantDetails } = useSelector(
    (state) => state.cancelBookingDataReducer
  );

  const onSubmit = () => {
    updateFormData({ ...formData, loading: true });
    const booking_Id = formData?.booking_id;
    axios
      .post(`${process.env.REACT_APP_API_URL}/booking-data-get-for-cancel`, {
        booking_number_id: booking_Id,
        restaurant_id: cancelBookingRestaurantDetails?.id,
      })
      .then((res) => {
        updateFormData({ ...formData, loading: false });
        dispatch(cancelBookingData(res.data.data));
        if (res.data.data.length !== 0) {
          navigate("/cancel-reservation-next");
        } else {
          message?.error(res?.data?.message);
        }
      });
  };

  return (
    <>
      <Navbar title={"Manage Booking"} leftIcon={<ArrowLeftIcon />} />

      <div className="cancel_reservation py-70 mt-4">
        <div className="container" style={{ paddingTop: "50px" }}>
          <div className="row align-items-center">
            <div className="col-sm-7">
              <h4 className="text-center font-weight-400 mb-60">
                Cancel reservation at{" "}
                <strong>
                  {cancelBookingRestaurantDetails?.restaurant_name}
                </strong>
              </h4>
              <h5 className="mt-4 ">Cancellation</h5>
              <p>
                Here you can cancel your booking. Enter your booking ID and the
                telephone no. you used when making the booking below.
              </p>
              <p>
                Your booking ID is to be found in your confirmation mail. if you
                do not have your booking ID please contact the restaurant.
              </p>

              <div className="row">
                <div className="col-md-6">
                  <div className="form-group">
                    <p className="formLabel">Booking ID</p>
                    <input
                      className="form-control"
                      type="text"
                      name="booking_id"
                      onChange={(e) => onChange(e)}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <p className="formLabel">Mobile Number</p>
                    <input
                      className="form-control"
                      type="tel"
                      name="mobile_num"
                      onChange={(e) => onChange(e)}
                    />
                  </div>
                </div>
              </div>
              <div className="d-grid px-50 pt-30">
                <button
                  className="btn btn-primary"
                  type="submit"
                  disabled={
                    formData?.booking_id === "" || formData?.mobile_num === ""
                  }
                  onClick={onSubmit}
                >
                  <Spin
                    spinning={formData?.loading}
                    className="mr-5 cancelBookSpin"
                  />
                  Next
                </button>
              </div>
              <div className="text-center">
                <Link
                  to={`/restaurant-table-booking/${cancelBookingRestaurantDetails?.id}`}
                  className="btn btn-link"
                >
                  Return without cancelling
                </Link>
              </div>
            </div>
            <div className="col-sm-5">
              <img
                src={ReservedImage}
                className="img-fluid cancel_reservation_image"
                alt="reserved"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CancelReservation;
