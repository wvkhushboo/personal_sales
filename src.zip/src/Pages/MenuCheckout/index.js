import React from "react";
import { useSelector } from "react-redux";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import Navbar from "../../Components/Navbar";
import placeHolder from "../../Assets/Images/placeHolder.jpg";
import "./index.css";
import { Empty } from "antd";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

const MenuCheckout = () => {
  const menuCart = useSelector((state) => state.menuCart);
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    console.log(data);
    navigate("/account");
  };

  return (
    <>
      <Navbar
        title={"Menu Checkout"}
        leftIcon={<ArrowLeftIcon to={"/sell-menu"} />}
      />

      <div
        className="container mt-4"
        style={{ paddingBottom: "120px", paddingTop: "50px" }}
      >
        <div className="row">
          <div className="col">
            {menuCart ? (
              <>
                {menuCart?.addedItems?.map((item) => (
                  <div className="menu-list mt-3" key={item.id}>
                    <div className="cart-menu">
                      <div>
                        <img
                          src={
                            item?.item_image
                              ? process.env.REACT_APP_API_URL.slice(0, -3) +
                                item?.item_image
                              : placeHolder
                          }
                          alt={item.item_name}
                        />
                      </div>
                      <div className="cart-content">
                        <h6>{item.item_name}</h6>
                        <h6>
                          <span style={{ color: "gray" }}>x</span>
                          {item.quantity}
                        </h6>
                        <h6>
                          € {(item.discount_value * item.quantity).toFixed(2)}
                        </h6>
                      </div>
                    </div>
                  </div>
                ))}
                <h6 className="total fw-bold">Total: € {menuCart.total}</h6>

                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="row justify-content-center">
                    <div className="col-md-6">
                      <div className="form-group">
                        <p className="formLabel">E-mail address</p>
                        <input
                          className="form-control"
                          type="text"
                          placeholder="Enter e-mail id"
                          {...register("email", {
                            required: "* Email is required",
                            pattern: {
                              value: RegExp(
                                "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,4}$"
                              ),
                              message: "Please enter a valid e-mail address",
                            },
                          })}
                        />
                        {errors.email && (
                          <span className="input-error">
                            {errors.email.message}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="row justify-content-center">
                    <div className="col-md-6">
                      <div className="form-group">
                        <p className="formLabel">Payment Method</p>

                        <select
                          style={{ maxWidth: "100%", borderRadius: "20px" }}
                          className="form-control"
                          {...register("method", {
                            required: "Payment method is required",
                          })}
                        >
                          <option value="Select payment method" disabled>
                            Select payment method
                          </option>
                          <option value="Cash">Cash</option>
                          <option value="Card">Card</option>
                        </select>
                        {errors.area && (
                          <span className="input-error">
                            {errors.area.message}
                          </span>
                        )}
                      </div>
                      <div className="text-center m-auto">
                        <button
                          className="btn"
                          style={{
                            width: "100%",
                            background: "#526bf3",
                            color: "white",
                            borderRadius: "20px",
                            marginTop: "10px",
                          }}
                        >
                          Book Now
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </>
            ) : (
              <div
                style={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                }}
              >
                <Empty description="No Menu Found" />
              </div>
            )}
          </div>
        </div>
      </div>

      <MobileFooter />
    </>
  );
};

export default MenuCheckout;
