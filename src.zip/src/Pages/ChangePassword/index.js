import React, { useState } from "react";

import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import { useForm } from "react-hook-form";

import "./index.css";
import EyeVisibleIcon from "../../Assets/Icons/EyeVisibleIcon";
import EyeInvisibleIcon from "../../Assets/Icons/EyeInvisibleIcon";
import { Button } from "antd-mobile";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import axios from "axios";
import { Alert } from "react-bootstrap";
import { logout } from "../../Redux/Actions/signInActions";
import { useDispatch } from "react-redux";
import { successNotify } from "../../helpers/notiication";

const ChangePassword = () => {
  const [alertMessage, setAlertMessage] = useState(false);
  const navigate = useNavigate();
  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  const [passwordToggle, setPasswordToggle] = useState({
    0: false,
    1: false,
    2: false,
  });
  const [newPassword, setNewPassword] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const dispatch = useDispatch();

  const onSubmit = (data) => {
    const setNewPassword = async () => {
      const { data: response } = await axios.post(
        `${process.env.REACT_APP_API_URL}/salesman/changePassword`,
        {
          old_password: data.oldPassword,
          new_password: data.newPassword,
          confirm_password: data.confirmPassword,
        },
        {
          headers: {
            Authorization: `Bearer ${logData.token}`,
          },
        }
      );

      if (response.message.includes("successfully")) {
        successNotify(
          response.message + "! Please login using new password..."
        );
        setTimeout(() => {
          localStorage.setItem(
            "Login",
            JSON.stringify({ isAuth: false, token: "" })
          );
          dispatch(logout());

          navigate("/", { replace: true });
        }, 3000);
      } else {
        setAlertMessage(response.message);
      }
    };

    setNewPassword();
  };

  return (
    <>
      <Navbar title="Change Password" leftIcon={<ArrowLeftIcon />} />
      <div className="container myPasswordContainer">
        <div className="alert-div">
          <Alert show={!!alertMessage} variant={"warning"}>
            <button onClick={() => setAlertMessage("")}>x</button>
            <span>{alertMessage}</span>
          </Alert>
        </div>

        <div className="passwordForm mt-5">
          <form onSubmit={handleSubmit(onSubmit)} className="mt-4">
            <div className="form-group">
              <p className="formLabel font-weight-bold">Old Password</p>
              <div className="passwithicon">
                <input
                  id="oldPassword"
                  className="form-control"
                  type={passwordToggle[0] ? "text" : "password"}
                  autoComplete="off"
                  {...register("oldPassword", {
                    required: "Old Password is required",
                    pattern: {
                      value: RegExp("(?=.*?[0-9])(?=.*?[A-Za-z]).+"),
                      message:
                        "Password should contain atleast one number and one alphabet",
                    },
                  })}
                />
                {errors.oldPassword && (
                  // <span className="input-error">{errors.email.message}</span>
                  <div className="alert alert-danger mt-3" role="alert">
                    {errors.oldPassword.message}
                  </div>
                )}
                {passwordToggle[0] ? (
                  <EyeVisibleIcon
                    onClick={() =>
                      setPasswordToggle((prev) => ({ ...prev, 0: !prev[0] }))
                    }
                  />
                ) : (
                  <EyeInvisibleIcon
                    onClick={() =>
                      setPasswordToggle((prev) => ({ ...prev, 0: !prev[0] }))
                    }
                  />
                )}
              </div>
            </div>
            <div className="form-group">
              <p className="formLabel font-weight-bold">New Password</p>
              <div className="passwithicon">
                <input
                  id="newPassword"
                  className="form-control"
                  type={passwordToggle[1] ? "text" : "password"}
                  autoComplete="off"
                  {...register("newPassword", {
                    required: "New Password is required",
                    pattern: {
                      value: RegExp("(?=.*?[0-9])(?=.*?[A-Za-z]).+"),
                      message:
                        "Password should contain atleast one number and one alphabet",
                    },
                  })}
                  onKeyUp={(e) => setNewPassword(e.target.value)}
                />
                {errors.newPassword && (
                  // <span className="input-error">{errors.email.message}</span>
                  <div className="alert alert-danger mt-3" role="alert">
                    {errors.newPassword.message}
                  </div>
                )}
                {passwordToggle[1] ? (
                  <EyeVisibleIcon
                    onClick={() =>
                      setPasswordToggle((prev) => ({ ...prev, 1: !prev[1] }))
                    }
                  />
                ) : (
                  <EyeInvisibleIcon
                    onClick={() =>
                      setPasswordToggle((prev) => ({ ...prev, 1: !prev[1] }))
                    }
                  />
                )}
              </div>
            </div>
            <div className="form-group">
              <p className="formLabel ">Confirm Password</p>
              <div className="passwithicon">
                <input
                  id="confirmPassword"
                  className="form-control"
                  type={passwordToggle[2] ? "text" : "password"}
                  autoComplete="off"
                  {...register("confirmPassword", {
                    required: "Confirm Password is required",
                    pattern: {
                      value: RegExp(`^${newPassword}$`),
                      message: "Passwords do not match! Please check...",
                    },
                  })}
                />
                {errors.confirmPassword && (
                  // <span className="input-error">{errors.email.message}</span>
                  <div className="alert alert-danger mt-3" role="alert">
                    {errors.confirmPassword.message}
                  </div>
                )}

                {passwordToggle[2] ? (
                  <EyeVisibleIcon
                    onClick={() =>
                      setPasswordToggle((prev) => ({ ...prev, 2: !prev[2] }))
                    }
                  />
                ) : (
                  <EyeInvisibleIcon
                    onClick={() =>
                      setPasswordToggle((prev) => ({ ...prev, 2: !prev[2] }))
                    }
                  />
                )}
              </div>
            </div>
            <div className="d-grid mt-4">
              <Button
                block
                shape="rounded"
                id="submit"
                type="submit"
                style={{ backgroundColor: "#526bf3", color: "white" }}
              >
                Change Password
              </Button>
            </div>
          </form>
        </div>
      </div>
      <MobileFooter />
    </>
  );
};

export default ChangePassword;
