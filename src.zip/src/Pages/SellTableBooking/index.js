import placeHolder from "../../Assets/Images/placeHolder.jpg";
import MobileFooter from "../../Components/MobileFooter/index";

import { useEffect, useState } from "react";
import axios from "axios";
import {
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication";
import { Empty, Spin } from "antd";
import "./index.css";
import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import { Button, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const SellTableBooking = (props) => {
  const [loading, setLoading] = useState(false);
  const [restaurants, setRestaurants] = useState([]);

  const navigate = useNavigate();

  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    setLoading(true);
    axios
      .get(`${process.env.REACT_APP_API_URL}/salesman/TableList`, {
        headers: {
          Authorization: `Bearer ${logData.token}`,
        },
      })
      .then((res) => {
        if (res.data.status === "201") {
          setRestaurants(res.data.table_list.restaurants);
        } else {
          internalErrorNotify();
        }
        setLoading(false);
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(navigate);
        } else {
          internalErrorNotify();
        }
        setLoading(false);
      });
    //eslint-disable-next-line
  }, []);

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  return (
    <>
      <Navbar title={"Choose Restaurant"} leftIcon={<ArrowLeftIcon />} />
      <div className="container eventContainer">
        <div className="row" style={{ justifyContent: "center" }}>
          <div className="col-md-10" style={{ paddingBottom: "120px" }}>
            <div className="mt-3 mb-3 EventCard">
              {loading ? (
                <div
                  className="NoRestaurantDiv"
                  style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  <Spin size="large" spinning={loading} tip="Loading..." />
                </div>
              ) : restaurants.length === 0 ? (
                <div
                  className="NoRestaurantDiv"
                  style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  <Empty description="No Restaurants Found" />
                </div>
              ) : (
                restaurants?.reverse().map((data) => (
                  <Card
                    onClick={() =>
                      navigate(`/restaurant-table-booking/${data.id}`)
                    }
                    className={"mb-3"}
                    key={data.id}
                  >
                    <Card.Img
                      variant="top"
                      src={
                        data?.logo_url
                          ? process.env.REACT_APP_API_URL.slice(0, -3) +
                            data?.logo_url
                          : placeHolder
                      }
                    />
                    <Card.Body>
                      <Card.Title>{data?.restaurant_name}</Card.Title>
                      <div className="card-text card-address">
                        <p>{data?.address}</p>
                        <i className="category">{data?.category_name}</i>
                      </div>
                    </Card.Body>
                    <Card.Body className="card-btn">
                      <Button>Book Now</Button>
                    </Card.Body>
                  </Card>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
      <MobileFooter />
    </>
  );
};

export default SellTableBooking;
