import React, { useState } from "react";

import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import {
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication.js";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Empty, Spin } from "antd";
import axios from "axios";
import { Card } from "react-bootstrap";
import placeHolder from "../../Assets/Images/placeHolder.jpg";
import "./index.css";
import { useDispatch, useSelector } from "react-redux";
import {
  addMenuToCart,
  removeMenuFromCart,
} from "../../Redux/Actions/menuCartActions";
import MenuFloatingBar from "../../Components/MenuFloatingBar";

const SellMenu = () => {
  const navigate = useNavigate();
  const logData = JSON.parse(localStorage.getItem("Login"));

  const [menuLoading, setMenuLoading] = useState(false);
  const [menuList, setMenuList] = useState([]);

  const menuCart = useSelector((state) => state.menuCart);

  const dispatch = useDispatch();

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }

    // eslint-disable-next-line
  }, [navigate, logData]);

  useEffect(() => {
    getMenuList();
    //eslint-disable-next-line
  }, []);

  const getMenuList = () => {
    setMenuLoading(true);

    axios
      .get(`${process.env.REACT_APP_API_URL}/salesman/menuList`, {
        headers: { Authorization: `Bearer ${logData?.token}` },
      })
      .then((res) => {
        setMenuList(res.data.menu);
        setMenuLoading(false);
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(navigate);
        } else {
          internalErrorNotify();
        }
        setMenuLoading(false);
      });
  };

  const handleMinusClick = (menu) => {
    dispatch(removeMenuFromCart(menu));
  };
  const handlePlusClick = (menu) => {
    dispatch(addMenuToCart(menu));
  };

  return (
    <>
      <Navbar title="Sell Menu" leftIcon={<ArrowLeftIcon />} />
      <div className="container" style={{ paddingTop: "50px" }}>
        <div className="container">
          <div className="row" style={{ justifyContent: "center" }}>
            <div className="col-md-10" style={{ paddingBottom: "120px" }}>
              <div className="mt-3 mb-3 EventCard">
                {menuLoading ? (
                  <div
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  >
                    <Spin spinning={true} tip="Loading..." size="large" />
                  </div>
                ) : menuList?.length === 0 ? (
                  <div
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  >
                    <Empty description="No Menu Found" />
                  </div>
                ) : (
                  !menuLoading &&
                  menuList &&
                  menuList?.map((menu, index) =>
                    menu.status === 1 ? (
                      <Card
                        onClick={() => {
                          // singleEventPop(data);
                          // dispatch(getSingleEventsAction(data?.id));
                        }}
                        className={"mb-3"}
                        key={menu.id}
                      >
                        <Card.Img
                          variant="top"
                          src={
                            menu?.item_image
                              ? process.env.REACT_APP_API_URL.slice(0, -3) +
                                menu?.item_image
                              : placeHolder
                          }
                        />
                        <Card.Body>
                          <Card.Title>
                            <div className="d-flex-container">
                              <p className="ellipsis">{menu?.item_name}</p>
                              <p className="inputNumwithbtn text-center">
                                <button
                                  className="num-btn num_min"
                                  onClick={() => handleMinusClick(menu)}
                                >
                                  <p className="fw-bold">-</p>
                                </button>
                                <input
                                  type={"number"}
                                  value={
                                    menuCart.addedItems.find(
                                      (item) => item.id === menu.id
                                    )
                                      ? menuCart.addedItems.find(
                                          (item) => item.id === menu.id
                                        ).quantity
                                      : 0
                                  }
                                  min={0}
                                  readOnly
                                />
                                <button
                                  className="num-btn num_plus"
                                  onClick={() => handlePlusClick(menu)}
                                >
                                  <p className="fw-bold">+</p>
                                </button>
                              </p>
                            </div>
                          </Card.Title>
                          <div className="d-flex-container">
                            <div className="card-text card-address">
                              <p className="addressPara fw-bold ellipsis">
                                {menu?.item_description}
                              </p>
                              <i className="category ellipsis">
                                {menu?.menu_category_name}
                              </i>
                            </div>
                            <div className="card-price">
                              <div className="epc_price">
                                <div className="prices">
                                  <div className="d_price ">
                                    <del className="font-size-14 fw-bold text-danger">
                                      € {menu?.item_price}
                                    </del>
                                  </div>
                                  <span className="fw-bold">
                                    € {menu?.discount_value}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </Card.Body>
                      </Card>
                    ) : null
                  )
                )}
              </div>
            </div>
          </div>
        </div>
        <MenuFloatingBar />
      </div>
      <MobileFooter />
    </>
  );
};

export default SellMenu;
