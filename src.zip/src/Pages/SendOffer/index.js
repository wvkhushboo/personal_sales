import React from "react";

import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Empty } from "antd";

const SendOffer = () => {
  const navigate = useNavigate();
  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  return (
    <>
      <>
        <Navbar title="Send Offer" leftIcon={<ArrowLeftIcon />} />
        <div className="container" style={{ paddingTop: "50px" }}>
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%,-50%)",
            }}
          >
            <Empty description="No Data Found" />
          </div>
        </div>
        <MobileFooter />
      </>
    </>
  );
};

export default SendOffer;
