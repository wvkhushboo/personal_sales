import React, { useState } from "react";

import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import {
  errorNotify,
  internalErrorNotify,
  unauthenticatedNotify,
} from "../../helpers/notiication.js";
import { Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import axios from "axios";
import { getSingleEventsAction } from "../../Redux/Actions/getSingleEventAction";
import { Empty, Spin } from "antd";
import UpcomingTicketEventPopup from "../../Components/Upcomingeventticketpopup";
import placeHolder from "../../Assets/Images/placeHolder.jpg";
import moment from "moment";
import "./index.css";
import { Button, Card } from "react-bootstrap";

const SellTickets = () => {
  const navigate = useNavigate();

  const logData = JSON.parse(localStorage.getItem("Login"));

  const [eventLoading, setEventLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedEvent, setSelectedEvent] = useState({});
  const [ticketData, setTicketData] = useState([]);
  const [show, setShow] = useState("");
  const dispatch = useDispatch();
  useEffect(() => {
    getHomeData();
    //eslint-disable-next-line
  }, [selectedCategory]);

  const place_categories = [
    {
      id: 1,
      name: "Concerts",
    },
    {
      id: 2,
      name: "Party",
    },
    {
      id: 3,
      name: "Dance",
    },
    {
      id: 4,
      name: "Music",
    },
  ];

  const getHomeData = () => {
    setEventLoading(true);
    const formdata = new FormData();
    formdata.append(
      "place_category_id",
      selectedCategory === "all" ? "all" : `[${selectedCategory}]`
    );
    // const formdata = new FormData();
    // formdata.append(
    //   "place_category_id",
    //   selectedCategory === "all" ? "all" : `[${selectedCategory}]`
    // );

    // console.log(params);

    // formdata.append("place_id", 27);
    axios
      .post(
        `${process.env.REACT_APP_API_URL}/salesman/ticketList`,
        {
          place_category_id:
            selectedCategory === "all" ? "all" : `[${selectedCategory}]`,
        },
        {
          headers: {
            Authorization: `Bearer ${logData.token}`,
          },
        }
      )
      .then((res) => {
        if (res.data.status === "201") {
          console.log(res.data.tickets);
          setTicketData(res.data.tickets);
          // setTicketData(uniqueTicketData);
        } else {
          internalErrorNotify();
        }
        setEventLoading(false);
      })
      .catch((error) => {
        if (error.response.status === 401) {
          unauthenticatedNotify(navigate);
        } else {
          errorNotify("Something went error!");
        }
        setEventLoading(false);
      });
  };
  const singleEventPop = (selectedEvent) => {
    setSelectedEvent(selectedEvent);
    document.body.classList.add("modal-open");
    setShow("show");
  };

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  console.log(ticketData?.place_categories);

  return (
    <>
      <>
        <Navbar title="Choose Tickets" leftIcon={<ArrowLeftIcon />} />

        <div className="container" style={{ paddingTop: "50px" }}>
          {/* <div className="text-center mt-3">
            <h4 className="font-weight-bold">Share/sell Tickets</h4>
          </div> */}

          {/* <TicketItemView /> */}
          <UpcomingTicketEventPopup
            show={show}
            setShow={setShow}
            setSelectedCategory={setSelectedCategory}
            homeData={ticketData}
            selectedEvent={selectedEvent}
          />

          <div className="tabBtns pt-30 pb-50 mt-3">
            <div className="container">
              <ul>
                <li
                  className={selectedCategory === "all" ? "active" : ""}
                  onClick={() => {
                    setSelectedCategory("all");
                  }}
                >
                  <Link to="#">All</Link>
                </li>
                {ticketData?.place_categories?.map((data) => (
                  <li
                    key={data.id}
                    className={
                      selectedCategory.includes(data.id) ? "active" : ""
                    }
                    onClick={() => {
                      !selectedCategory.includes(data.id)
                        ? setSelectedCategory(
                            selectedCategory === "all"
                              ? [data.id]
                              : [...selectedCategory, data.id]
                          )
                        : selectedCategory.length !== 1 &&
                          setSelectedCategory(
                            selectedCategory.filter((id) => id !== data.id)
                          );
                    }}
                  >
                    <Link to="#">{data.name}</Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="container">
            <div className="row" style={{ justifyContent: "center" }}>
              <div className="col-md-10" style={{ paddingBottom: "120px" }}>
                <div className="mt-3 mb-3 EventCard">
                  {eventLoading ? (
                    <div
                      style={{
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                      }}
                    >
                      <Spin spinning={true} tip="Loading..." size="large" />
                    </div>
                  ) : ticketData?.length === 0 ? (
                    <div
                      style={{
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                      }}
                    >
                      <Empty description="No Events  Found" />
                    </div>
                  ) : (
                    !eventLoading &&
                    ticketData?.ticket.reverse().map((data) => (
                      <Card
                        onClick={() => {
                          singleEventPop(data);
                          dispatch(getSingleEventsAction(data));
                        }}
                        className={"mb-3"}
                        key={data.id}
                      >
                        <Card.Img
                          variant="top"
                          src={
                            data?.ticket_image
                              ? process.env.REACT_APP_API_URL.slice(0, -3) +
                                data?.ticket_image
                              : placeHolder
                          }
                        />
                        <Card.Body>
                          <Card.Title>
                            <span className="ellipsis">
                              {data?.ticket_name}
                            </span>
                          </Card.Title>
                          <div className="card-text card-address">
                            <p className="time">
                              {" "}
                              {moment(data?.event_start_date).format(
                                "DD MMM YYYY"
                              )}{" "}
                              {"-"}{" "}
                              {moment(data?.event_end_date).format(
                                "DD MMM YYYY"
                              )}
                            </p>
                            <p className="addressPara fw-bold">
                              {data?.restaurant_tickets?.map(
                                (place) => place.restaurant_name
                              )}
                            </p>
                            <p className="">
                              {data?.restaurant_tickets?.map(
                                (place) => place.address
                              )}
                            </p>
                            <i className="category">{data?.category_name}</i>
                          </div>
                        </Card.Body>
                        <Card.Body className="card-price">
                          <div className="epc_price">
                            <div className="prices">
                              <div className="d_price ">
                                <del className="font-size-14 fw-bold text-danger">
                                  {data?.ticket_price_infos.length === 0
                                    ? " "
                                    : `€ ${data?.ticket_price_infos[0].ticket_price}`}
                                </del>
                              </div>
                              <div className="d_price">
                                <span className="text-success">
                                  {data?.ticket_price_infos.length === 0
                                    ? "Free Entry"
                                    : `(${(
                                        100 -
                                        (data?.ticket_price_infos[0]
                                          .sales_price *
                                          100) /
                                          data?.ticket_price_infos[0]
                                            .ticket_price
                                      ).toFixed(0)}% OFF)`}
                                </span>
                              </div>
                              <span className="fw-bold">
                                {data?.ticket_price_infos.length === 0
                                  ? " "
                                  : `€ ${data?.ticket_price_infos[0].sales_price}`}
                              </span>
                            </div>
                          </div>
                          <Button>Book Now</Button>
                        </Card.Body>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileFooter />
      </>
    </>
  );
};

export default SellTickets;
