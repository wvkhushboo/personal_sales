import React from "react";

import Navbar from "../../Components/Navbar";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import MobileFooter from "../../Components/MobileFooter";
import { Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Table } from "react-bootstrap";

const MyCommission = () => {
  const navigate = useNavigate();
  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  return (
    <>
      <>
        <Navbar title="My Commission" leftIcon={<ArrowLeftIcon />} />

        <div className="container" style={{ paddingTop: "50px" }}>
          <div className="row text-center mt-4">
            <div className="col">
              <h2 className="fw-bold">Sold Tickets & Revenue</h2>
            </div>
          </div>
          <div className="row border-bottom">
            <div className="col">
              <div className="tabBtns pt-30 pb-50 mt-3">
                <div className="container">
                  <ul>
                    <li className={"active"} onClick={() => {}}>
                      <Link to="#">Today</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Week</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Month</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Custom</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <div className="tabBtns pt-30 pb-50 mt-3">
                <div className="container">
                  <ul>
                    <li className={"active"} onClick={() => {}}>
                      <Link to="#">Tickets</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Bookings</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Offer</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Promo</Link>
                    </li>
                    <li onClick={() => {}}>
                      <Link to="#">Commissions</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="row mt-4">
            <div className="col">
              <Table borderless responsive>
                <thead>
                  <tr>
                    <th>Ticket</th>
                    <th>Contact</th>
                    <th>Price</th>
                    <th>Payment Method</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Ticket to Moon</td>
                    <td>info@moon.com</td>
                    <td>$30</td>
                    <td>
                      Card{" "}
                      <Link className="text-black" to={"#"}>
                        Refund
                      </Link>
                    </td>
                  </tr>
                  <tr>
                    <td>Ticket to Moon</td>
                    <td>info@moon.com</td>
                    <td>$30</td>
                    <td>
                      Card{" "}
                      <Link className="text-black" to={"#"}>
                        Refund
                      </Link>
                    </td>
                  </tr>
                  <tr>
                    <td>Ticket to Moon</td>
                    <td>info@moon.com</td>
                    <td>$30</td>
                    <td>
                      Card{" "}
                      <Link className="text-black" to={"#"}>
                        Refund
                      </Link>
                    </td>
                  </tr>
                </tbody>
              </Table>
            </div>
          </div>
        </div>
        <MobileFooter />
      </>
    </>
  );
};

export default MyCommission;
