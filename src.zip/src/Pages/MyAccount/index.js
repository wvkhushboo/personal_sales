import React from "react";
import Navbar from "../../Components/Navbar";
import MobileFooter from "../../Components/MobileFooter";
import ArrowLeftIcon from "../../Assets/Icons/ArrowLeftIcon";
import EditIcon from "../../Assets/Icons/EditIcon";

import "./index.css";
import { Link, useNavigate } from "react-router-dom";
import RightSignIcon from "../../Assets/Icons/RightSignIcon";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useState } from "react";
import axios from "axios";
import { Skeleton } from "antd-mobile";
import { logout } from "../../Redux/Actions/signInActions";
import LogoutIcon from "../../Assets/Icons/LogoutIcon";
import { Button, Modal } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { internalErrorNotify, successNotify } from "../../helpers/notiication";

const MyAccount = () => {
  const [salesmanDetails, setSalesmanDetails] = useState({});
  const [modalShow, setModalShow] = React.useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  const navigate = useNavigate();

  const dispatch = useDispatch();

  const logData = JSON.parse(localStorage.getItem("Login"));

  useEffect(() => {
    if (logData?.isAuth === false) {
      navigate("/", { replace: true });
    }
  }, [navigate, logData]);

  const signout = () => {
    localStorage.setItem("Login", JSON.stringify({ isAuth: false, token: "" }));
    dispatch(logout());
    navigate("/");
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ mode: "onChange" });

  const fetchUserDetails = async () => {
    const { data: response } = await axios.get(
      `${process.env.REACT_APP_API_URL}/salesman/profile`,
      {
        headers: {
          Authorization: `Bearer ${logData.token}`,
        },
      }
    );
    setSalesmanDetails(response.data);
  };

  useEffect(() => {
    fetchUserDetails();
    //eslint-disable-next-line
  }, []);

  const countries = {
    1: "India",
    2: "United States",
  };

  const onSubmit = (data) => {
    axios
      .post(
        `${process.env.REACT_APP_API_URL}/salesman/updateProfile`,
        {
          first_name: data.fullName.split(" ")[0],
          last_name: data.fullName.split(" ")[1],
          email: data.email,
          company_name: data.company_name,
          address: data.address,
          city: data.city,
          country_id: data.country,
          tax_id: data.tax_id,
          phone_number: data.phone_number,
        },
        {
          headers: { Authorization: `Bearer ${logData.token}` },
        }
      )
      .then((res) => {
        successNotify("Profile updated successfully!");
        setIsEditMode(false);
      })
      .catch((err) => {
        console.log(err);
        internalErrorNotify();
      });
  };

  return (
    <>
      <>
        <Navbar
          title="My Account"
          leftIcon={<ArrowLeftIcon />}
          rightIcon={
            <EditIcon onClick={() => setIsEditMode((prev) => !prev)} />
          }
        />
        <div className="myAccountContainer">
          <div className="container mt-4">
            <ul className="data-list">
              <form onSubmit={handleSubmit(onSubmit)} className="mt-4">
                <div className="form-group">
                  <p className="formLabel font-weight-bold">Full Name</p>
                  {salesmanDetails?.first_name && salesmanDetails?.last_name ? (
                    <div className="passwithicon">
                      <input
                        id="fullName"
                        className="form-control"
                        type={"text"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        {...register("fullName", {
                          required: "Full name is required",
                          value: `${salesmanDetails?.first_name} ${salesmanDetails?.last_name}`,
                        })}
                      />
                      {errors.fullName && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.fullName.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>
                <div className="form-group">
                  <p className="formLabel font-weight-bold">Email</p>
                  {salesmanDetails?.email ? (
                    <div className="passwithicon">
                      <input
                        id="email"
                        className="form-control"
                        type={"email"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        {...register("email", {
                          required: "Email is required",
                          value: `${salesmanDetails?.email}`,
                        })}
                      />
                      {errors.email && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.email.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>
                <div className="form-group">
                  <p className="formLabel font-weight-bold">Company Name</p>
                  {salesmanDetails?.company_name ? (
                    <div className="passwithicon">
                      <input
                        id="company_name"
                        className="form-control"
                        type={"text"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        {...register("company_name", {
                          required: "Company Name is required",
                          value: `${salesmanDetails?.company_name}`,
                        })}
                      />
                      {errors.company_name && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.company_name.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>
                <div className="form-group">
                  <p className="formLabel font-weight-bold">Address</p>
                  {salesmanDetails?.address ? (
                    <div className="passwithicon">
                      <input
                        id="address"
                        className="form-control"
                        type={"text"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        {...register("address", {
                          required: "Address is required",
                          value: `${salesmanDetails?.address}`,
                        })}
                      />
                      {errors.address && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.address.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>

                <div className="form-group">
                  <p className="formLabel font-weight-bold">City</p>
                  {salesmanDetails?.city ? (
                    <div className="passwithicon">
                      <input
                        id="city"
                        className="form-control"
                        type={"text"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        {...register("city", {
                          required: "City is required",
                          value: `${salesmanDetails?.city}`,
                        })}
                      />
                      {errors.city && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.city.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>

                <div className="form-group">
                  <p className="formLabel font-weight-bold">Country</p>
                  {salesmanDetails?.country_id ? (
                    <div className="passwithicon">
                      <select
                        id="country"
                        style={{ borderRadius: "20px" }}
                        className="form-control"
                        disabled={!isEditMode}
                        defaultValue={salesmanDetails?.country_id}
                        {...register("country", {
                          required: "Country is required",
                        })}
                      >
                        {Object.keys(countries).map((key) => (
                          <option key={key} value={key}>
                            {countries[key]}
                          </option>
                        ))}
                      </select>
                      {errors.country && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.country.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>

                <div className="form-group">
                  <p className="formLabel font-weight-bold">Tax Number</p>
                  {salesmanDetails?.tax_id ? (
                    <div className="passwithicon">
                      <input
                        id="tax_id"
                        className="form-control"
                        type={"text"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        {...register("tax_id", {
                          required: "Tax Number is required",
                          value: `${salesmanDetails?.tax_id}`,
                        })}
                      />
                      {errors.tax_id && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.tax_id.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>

                <div className="form-group">
                  <p className="formLabel font-weight-bold">Phone Number</p>
                  {salesmanDetails?.phone_number ? (
                    <div className="passwithicon">
                      <input
                        id="phone_number"
                        className="form-control"
                        type={"tel"}
                        disabled={!isEditMode}
                        autoComplete="off"
                        maxLength={10}
                        {...register("phone_number", {
                          required: "Phone number is required",
                          value: `${salesmanDetails?.phone_number}`,
                          minLength: {
                            value: 10,
                            message: "Please enter a 10 digit mobile number",
                          },
                          maxLength: {
                            value: 10,
                            message: "Please enter a 10 digit mobile number",
                          },
                          pattern: {
                            value: /^[0-9]+$/,
                            message:
                              "Please enter a valid 10 digit mobile number",
                          },
                        })}
                      />
                      {errors.phone_number && (
                        <div className="alert alert-danger mt-3" role="alert">
                          {errors.phone_number.message}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </div>

                {isEditMode && (
                  <div className="d-grid mt-3 mb-2">
                    <Button
                      shape="rounded"
                      id="submit"
                      type="submit"
                      style={{ backgroundColor: "#526bf3", color: "white" }}
                    >
                      Update
                    </Button>
                  </div>
                )}
              </form>
              {/* <li>
                <p className="font-weight-bold">Full Name</p>
                <span>
                  {salesmanDetails.first_name && salesmanDetails.last_name ? (
                    <>
                      {salesmanDetails.first_name} {salesmanDetails.last_name}
                    </>
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li>
              <li className="mt-3">
                <p className="font-weight-bold">Email</p>
                <span>
                  {salesmanDetails.email ? (
                    salesmanDetails.email
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li>
              <li className="mt-3">
                <p className="font-weight-bold">Company Name</p>
                <span>
                  {salesmanDetails.company_name ? (
                    salesmanDetails.company_name
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li>
              <li className="mt-3">
                <p className="font-weight-bold">Address</p>
                <span>
                  {salesmanDetails.address ? (
                    salesmanDetails.address
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li>
              <li className="mt-3">
                <p className="font-weight-bold">Country</p>
                <span>
                  {salesmanDetails.country_id ? (
                    salesmanDetails.country_id === 1 ? (
                      "India"
                    ) : (
                      "US"
                    )
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li>
              <li className="mt-3">
                <p className="font-weight-bold">Tax Number</p>
                <span>
                  {salesmanDetails.tax_id ? (
                    salesmanDetails.tax_id
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li> */}
              {/* <li className="mt-3">
                <p className="font-weight-bold">Company Number</p>
                <span>
                  {salesmanDetails.company_number ? (
                    salesmanDetails.company_number
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li> */}
              {/* <li className="mt-3 mb-3">
                <p className="font-weight-bold">Telephone</p>
                <span>
                  {salesmanDetails.phone_number ? (
                    salesmanDetails.phone_number
                  ) : (
                    <Skeleton.Title animated />
                  )}
                </span>
              </li> */}
              <Link to="/change-password">
                <li className="border-bottom border-top">
                  <span className="font-weight-bold">Change Password</span>
                  <span style={{ float: "right", marginRight: "5px" }}>
                    <RightSignIcon />
                  </span>
                </li>
              </Link>
              <Link to="/my-commission">
                <li className="border-bottom">
                  <span className="font-weight-bold">My Commission</span>
                  <span style={{ float: "right", marginRight: "5px" }}>
                    <RightSignIcon />
                  </span>
                </li>
              </Link>
              <Link to="/my-account" onClick={() => setModalShow(true)}>
                <li style={{ paddingBottom: "5px" }}>
                  <span className="font-weight-bold">Logout</span>
                  <span
                    style={{
                      float: "right",
                      marginRight: "5px",
                    }}
                  >
                    <RightSignIcon />
                  </span>
                </li>
              </Link>
            </ul>
          </div>
        </div>
        <Modal
          size="lg"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          show={modalShow}
        >
          <Modal.Body className="text-center">
            <LogoutIcon />
            <h5 className="mt-2">Are you sure?</h5>
            <h5>You want to Logout</h5>
            <div className="mt-3 modalBtn">
              <Button
                onClick={() => {
                  setModalShow(false);
                  signout();
                }}
                className="me-2"
              >
                Logout
              </Button>
              <Button onClick={() => setModalShow(false)}>Close</Button>
            </div>
          </Modal.Body>
        </Modal>

        <MobileFooter />
      </>
    </>
  );
};

export default MyAccount;
