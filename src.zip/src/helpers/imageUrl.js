export const SERVER_URL = "http://hhr.webvilleedemo.xyz/";
