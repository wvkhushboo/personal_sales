export const getTicketType = (ticket_type, repeat_count) => {
  switch (ticket_type) {
    case 1:
      return "Single Ticket";
    case 2:
      return `Multiple Ticket ` + repeat_count + " times";
    case 3:
      return "Value Ticket";
    case 4:
      return "Time-Based Ticket";
    case 5:
      return "Discount Coupon";
    case 6:
      return "Personalised Ticket";

    default:
      break;
  }
};
