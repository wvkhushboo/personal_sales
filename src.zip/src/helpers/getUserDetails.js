import axios from "../axios";
import store from "store";

export const getUserDetails = async () => {
  const result = await axios.get("get-user-details", {
    headers: {
      Authorization: `Bearer ${store.get("hhr_token")}`,
    },
  });

  return result;
};
