import { message, notification } from "antd";

export const successNotify = (msg) => {
  message.success(msg);
};

export const errorNotify = (msg) => {
  message.error(msg);
};

export const unauthenticatedNotify = (history) => {
  localStorage.setItem("Login", JSON.stringify({ isAuth: false, token: "" }));
  notification.error({
    message: "Session Expired",
    description: "Your Session has been expired, Kindly Login again!!",
  });
  history("/");
};

export const internalErrorNotify = () => {
  notification.error({
    message: "Something Went Wrong",
    description: "Kindly try after some time",
  });
};
