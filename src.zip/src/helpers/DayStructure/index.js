export const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

export const dayWithStatus = [{
    day: 'Monday',
    statusCode: 0,
},
{
    day: 'Tuesday',
    statusCode: 1,
},
{
    day: 'Wednesday',
    statusCode: 2,
},
{
    day: 'Thursday',
    statusCode: 3,
},
{
    day: 'Friday',
    statusCode: 4,
},
{
    day: 'Saturday',
    statusCode: 5,
},
{
    day: 'Sunday',
    statusCode: 6,
},
]