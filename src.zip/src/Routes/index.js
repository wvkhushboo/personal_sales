import React from "react";

import { Routes as Router, Route } from "react-router-dom";

import Email from "../Components/Email";
import Password from "../Components/Password";
import Home from "../Pages/Home";
import SellTableBooking from "../Pages/SellTableBooking";
import Account from "../Pages/AccountPage";
import SellMenu from "../Pages/SellMenu";
import SellTickets from "../Pages/SellTickets";
import MyAccount from "../Pages/MyAccount";
import ChangePassword from "../Pages/ChangePassword";
import PageNotFound from "../Pages/PageNotFound";
import SuccessQrPage from "../Pages/SuccessQrPage";
import RestaurantTableBooking from "../Pages/RestaurantTableBooking";
import CancelReservation from "../Pages/CancelReservation";
import SendOffer from "../Pages/SendOffer";
import MyCommission from "../Pages/MyCommission";
import MenuCheckout from "../Pages/MenuCheckout";

const Routes = () => {
  return (
    <Router>
      <Route path="/" element={<Email />} />
      <Route path="/password" element={<Password />} />
      <Route path="/home" element={<Home />} />
      <Route path="/account" element={<Account />} />
      <Route path="/sell-tickets" element={<SellTickets />} />
      <Route path="/sell-table-booking" element={<SellTableBooking />} />
      <Route path="/sell-menu" element={<SellMenu />} />
      <Route path="/send-offer" element={<SendOffer />} />
      <Route path="/my-account" element={<MyAccount />} />
      <Route path="/my-commission" element={<MyCommission />} />
      <Route path="/change-password" element={<ChangePassword />} />
      <Route path="/event-cart/stripe-event" element={<SuccessQrPage />} />
      <Route
        path="/restaurant-table-booking/:id"
        element={<RestaurantTableBooking />}
      />
      <Route path="/cancel-reservation" element={<CancelReservation />} />
      <Route path="/menu-checkout" element={<MenuCheckout />} />
      <Route path="*" element={<PageNotFound />} />
    </Router>
  );
};

export default Routes;
